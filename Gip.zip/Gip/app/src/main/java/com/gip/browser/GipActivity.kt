package com.gip.browser

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * Base commune à tous les écrans de Gip : applique la couleur d'accent
 * choisie dans Paramètres > Apparence avant l'inflation de la vue, et
 * recrée l'écran s'il était déjà ouvert quand la couleur a changé ailleurs
 * (ex. onglet Paramètres en arrière-plan de MainActivity).
 */
open class GipActivity : AppCompatActivity() {

    private var appliedThemeId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        appliedThemeId = Prefs.accentThemeId(this)
        setTheme(Prefs.accentThemeStyleRes(this))
        super.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        if (appliedThemeId != null && appliedThemeId != Prefs.accentThemeId(this)) {
            recreate()
        }
    }
}
