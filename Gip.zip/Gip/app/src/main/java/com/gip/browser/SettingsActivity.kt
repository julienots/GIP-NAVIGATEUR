package com.gip.browser

import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.gip.browser.databinding.ActivitySettingsBinding
import java.io.File

class SettingsActivity : GipActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }

        val currentEngine = Prefs.searchEngineId(this)
        for (i in 0 until binding.searchEngineGroup.childCount) {
            val radio = binding.searchEngineGroup.getChildAt(i) as? RadioButton ?: continue
            if (radio.tag == currentEngine) radio.isChecked = true
        }
        binding.searchEngineGroup.setOnCheckedChangeListener { group, checkedId ->
            val radio = group.findViewById<RadioButton>(checkedId)
            val id = radio?.tag?.toString() ?: return@setOnCheckedChangeListener
            Prefs.setSearchEngineId(this, id)
        }

        binding.switchDesktopDefault.isChecked = Prefs.isDesktopDefault(this)
        binding.switchDesktopDefault.setOnCheckedChangeListener { _, checked ->
            Prefs.setDesktopDefault(this, checked)
        }

        binding.switchSafeSearch.isChecked = Prefs.isSafeSearchEnabled(this)
        binding.switchSafeSearch.setOnCheckedChangeListener { _, checked ->
            Prefs.setSafeSearchEnabled(this, checked)
        }

        setupAccentSwatches()
        setupTextZoom()

        binding.btnClearData.setOnClickListener { confirmClearData() }
        binding.btnClearCache.setOnClickListener { clearCacheOnly() }
        binding.btnClearCookies.setOnClickListener { clearCookiesOnly() }
        binding.btnClearSearchHistory.setOnClickListener { clearGipSearchHistory() }
    }

    // ---------------------------------------------------------------
    // Apparence : couleur d'accent
    // ---------------------------------------------------------------

    private fun setupAccentSwatches() {
        val swatches = mapOf(
            "teal" to binding.swatchTeal,
            "blue" to binding.swatchBlue,
            "purple" to binding.swatchPurple,
            "pink" to binding.swatchPink,
            "red" to binding.swatchRed,
            "orange" to binding.swatchOrange,
            "green" to binding.swatchGreen
        )
        fun refreshSelection() {
            val current = Prefs.accentThemeId(this)
            for ((id, view) in swatches) {
                view.setBackgroundResource(
                    if (id == current) R.drawable.bg_color_swatch_selected else R.drawable.bg_color_swatch
                )
            }
        }
        for ((id, view) in swatches) {
            view.setOnClickListener {
                Prefs.setAccentThemeId(this, id)
                refreshSelection()
                // La couleur d'accent est une couleur de thème (voir themes.xml) :
                // on recrée l'écran pour l'appliquer tout de suite. MainActivity,
                // s'il était en arrière-plan, se recrée à son tour à la reprise
                // (voir GipActivity.onResume) et retrouve ses onglets sauvegardés.
                recreate()
            }
        }
        refreshSelection()
    }

    // ---------------------------------------------------------------
    // Apparence : taille du texte des pages web
    // ---------------------------------------------------------------

    private fun setupTextZoom() {
        val current = Prefs.textZoom(this)
        for (i in 0 until binding.textZoomGroup.childCount) {
            val radio = binding.textZoomGroup.getChildAt(i) as? RadioButton ?: continue
            if (radio.tag?.toString()?.toIntOrNull() == current) radio.isChecked = true
        }
        binding.textZoomGroup.setOnCheckedChangeListener { group, checkedId ->
            val radio = group.findViewById<RadioButton>(checkedId)
            val percent = radio?.tag?.toString()?.toIntOrNull() ?: return@setOnCheckedChangeListener
            Prefs.setTextZoom(this, percent)
        }
    }

    // ---------------------------------------------------------------
    // Données de navigation
    // ---------------------------------------------------------------

    private fun confirmClearData() {
        AlertDialog.Builder(this)
            .setTitle("Effacer les données de navigation")
            .setMessage("Cela va supprimer l'historique, les cookies et le cache de navigation. Les favoris sont conservés.")
            .setPositiveButton("Effacer") { _, _ ->
                DbHelper(this).clearHistory()
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                WebStorage.getInstance().deleteAllData()
                deleteCacheFiles()
                Toast.makeText(this, "Données de navigation effacées", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun clearCacheOnly() {
        WebStorage.getInstance().deleteAllData()
        deleteCacheFiles()
        Toast.makeText(this, "Cache effacé", Toast.LENGTH_SHORT).show()
    }

    private fun clearCookiesOnly() {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        Toast.makeText(this, "Cookies effacés", Toast.LENGTH_SHORT).show()
    }

    private fun clearGipSearchHistory() {
        DbHelper(this).clearSearchHistory()
        Toast.makeText(this, "Recherches Gip Search effacées", Toast.LENGTH_SHORT).show()
    }

    /** Supprime le cache disque de la WebView (répertoire cache de l'appli). */
    private fun deleteCacheFiles() {
        try {
            deleteRecursively(cacheDir)
        } catch (e: Exception) {
            // Pas grave : au pire le cache se re-remplira normalement, rien à signaler.
        }
    }

    private fun deleteRecursively(file: File) {
        if (file.isDirectory) {
            file.listFiles()?.forEach { deleteRecursively(it) }
        }
        file.delete()
    }
}
