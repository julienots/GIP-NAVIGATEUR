package com.gip.browser

import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.widget.RadioButton
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.gip.browser.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }

        val currentEngine = Prefs.searchEngineId(this)
        for (i in 0 until binding.searchEngineGroup.childCount) {
            val radio = binding.searchEngineGroup.getChildAt(i) as? RadioButton ?: continue
            if (radio.tag == currentEngine) radio.isChecked = true
        }
        binding.searchEngineGroup.setOnCheckedChangeListener { group, checkedId ->
            val radio = group.findViewById<RadioButton>(checkedId)
            val id = radio?.tag?.toString() ?: return@setOnCheckedChangeListener
            Prefs.setSearchEngineId(this, id)
        }

        binding.switchDesktopDefault.isChecked = Prefs.isDesktopDefault(this)
        binding.switchDesktopDefault.setOnCheckedChangeListener { _, checked ->
            Prefs.setDesktopDefault(this, checked)
        }

        binding.btnClearData.setOnClickListener { confirmClearData() }
    }

    private fun confirmClearData() {
        AlertDialog.Builder(this)
            .setTitle("Effacer les données de navigation")
            .setMessage("Cela va supprimer l'historique, les cookies et le cache de navigation. Les favoris sont conservés.")
            .setPositiveButton("Effacer") { _, _ ->
                DbHelper(this).clearHistory()
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                WebStorage.getInstance().deleteAllData()
                Toast.makeText(this, "Données de navigation effacées", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }
}
