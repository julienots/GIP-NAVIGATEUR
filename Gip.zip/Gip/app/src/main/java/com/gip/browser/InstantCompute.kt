package com.gip.browser

import java.util.Locale
import kotlin.math.pow

/**
 * Réponses instantanées calculées entièrement en local (aucune requête
 * réseau) : calculs arithmétiques et conversions d'unités courantes. Résultat
 * affiché avant même que les résultats web n'arrivent.
 */
object InstantCompute {

    data class Answer(val expression: String, val result: String)

    fun compute(query: String): Answer? {
        val trimmed = query.trim()
        conversion(trimmed)?.let { return it }
        arithmetic(trimmed)?.let { return it }
        randomAnswer(trimmed)?.let { return it }
        return dateTimeAnswer(trimmed)
    }

    // -----------------------------------------------------------------
    // Calculatrice : expressions du type "12 * (4 + 2) / 3"
    // -----------------------------------------------------------------

    private fun arithmetic(input: String): Answer? {
        // N'accepte que des caractères de calcul : évite de tenter d'évaluer
        // une requête texte ordinaire ("comment ça va" etc.)
        val cleaned = input.replace(",", ".").replace(" ", "")
        if (cleaned.isBlank()) return null
        if (!cleaned.matches(Regex("^[0-9+\\-*/^().]+$"))) return null
        // Il faut au moins un opérateur pour ne pas "calculer" un simple nombre tapé seul.
        if (!cleaned.any { it in "+-*/^" } || cleaned.count { it.isDigit() } == 0) return null
        return try {
            val value = ExpressionParser(cleaned).parse()
            val formatted = if (value == value.toLong().toDouble()) {
                value.toLong().toString()
            } else {
                String.format(Locale.FRANCE, "%.6f", value).trimEnd('0').trimEnd(',')
            }
            Answer(input.trim(), formatted)
        } catch (e: Exception) {
            null
        }
    }

    /** Petit parseur récursif descendant : + - * / ^ () et nombres décimaux. */
    private class ExpressionParser(private val text: String) {
        private var pos = 0

        fun parse(): Double {
            val value = parseExpr()
            if (pos != text.length) throw IllegalArgumentException("Expression invalide")
            return value
        }

        private fun parseExpr(): Double {
            var value = parseTerm()
            while (pos < text.length && (text[pos] == '+' || text[pos] == '-')) {
                val op = text[pos++]
                val rhs = parseTerm()
                value = if (op == '+') value + rhs else value - rhs
            }
            return value
        }

        private fun parseTerm(): Double {
            var value = parseFactor()
            while (pos < text.length && (text[pos] == '*' || text[pos] == '/')) {
                val op = text[pos++]
                val rhs = parseFactor()
                value = if (op == '*') value * rhs else value / rhs
            }
            return value
        }

        private fun parseFactor(): Double {
            var value = parseUnary()
            if (pos < text.length && text[pos] == '^') {
                pos++
                val exponent = parseFactor()
                value = value.pow(exponent)
            }
            return value
        }

        private fun parseUnary(): Double {
            if (pos < text.length && text[pos] == '-') {
                pos++
                return -parseUnary()
            }
            return parseAtom()
        }

        private fun parseAtom(): Double {
            if (pos < text.length && text[pos] == '(') {
                pos++
                val value = parseExpr()
                if (pos >= text.length || text[pos] != ')') throw IllegalArgumentException("Parenthèse manquante")
                pos++
                return value
            }
            val start = pos
            while (pos < text.length && (text[pos].isDigit() || text[pos] == '.')) pos++
            if (start == pos) throw IllegalArgumentException("Nombre attendu")
            return text.substring(start, pos).toDouble()
        }
    }

    // -----------------------------------------------------------------
    // Conversions : "10 km en miles", "20 c en f", "5 kg en lb"
    // -----------------------------------------------------------------

    private val CONVERSIONS: Map<Pair<String, String>, (Double) -> Double> = mapOf(
        ("km" to "mi") to { v -> v * 0.621371 },
        ("mi" to "km") to { v -> v / 0.621371 },
        ("m" to "ft") to { v -> v * 3.28084 },
        ("ft" to "m") to { v -> v / 3.28084 },
        ("kg" to "lb") to { v -> v * 2.20462 },
        ("lb" to "kg") to { v -> v / 2.20462 },
        ("g" to "oz") to { v -> v * 0.035274 },
        ("oz" to "g") to { v -> v / 0.035274 },
        ("l" to "gal") to { v -> v * 0.264172 },
        ("gal" to "l") to { v -> v / 0.264172 },
        ("c" to "f") to { v -> v * 9.0 / 5.0 + 32 },
        ("f" to "c") to { v -> (v - 32) * 5.0 / 9.0 },
        ("cm" to "in") to { v -> v / 2.54 },
        ("in" to "cm") to { v -> v * 2.54 },
        ("kmh" to "mph") to { v -> v * 0.621371 },
        ("mph" to "kmh") to { v -> v / 0.621371 }
    )

    private val UNIT_LABELS = mapOf(
        "km" to "km", "mi" to "miles", "m" to "m", "ft" to "pieds",
        "kg" to "kg", "lb" to "livres", "g" to "g", "oz" to "oz",
        "l" to "litres", "gal" to "gallons", "c" to "°C", "f" to "°F",
        "cm" to "cm", "in" to "pouces", "kmh" to "km/h", "mph" to "mph"
    )

    private val CONVERSION_REGEX = Regex(
        "^([0-9]+(?:[.,][0-9]+)?)\\s*([a-zA-Z°]+)\\s+(?:en|to|in)\\s+([a-zA-Z°]+)$",
        RegexOption.IGNORE_CASE
    )

    private fun conversion(input: String): Answer? {
        val match = CONVERSION_REGEX.matchEntire(input.trim()) ?: return null
        val value = match.groupValues[1].replace(",", ".").toDoubleOrNull() ?: return null
        val from = match.groupValues[2].lowercase().removePrefix("°")
        val to = match.groupValues[3].lowercase().removePrefix("°")
        val fn = CONVERSIONS[from to to] ?: return null
        val result = fn(value)
        val formatted = String.format(Locale.FRANCE, "%.3f", result).trimEnd('0').trimEnd(',')
        val fromLabel = UNIT_LABELS[from] ?: from
        val toLabel = UNIT_LABELS[to] ?: to
        return Answer("$value $fromLabel", "$formatted $toLabel")
    }

    // -----------------------------------------------------------------
    // Hasard : "pile ou face", "dé", "dé 20", "nombre aléatoire entre 1 et 100"
    // -----------------------------------------------------------------

    private val COIN_FLIP_REGEX = Regex(
        "^(?:pile\\s+ou\\s+face|lance[rz]?\\s+une?\\s+pi[eè]ce)\\s*\\??$",
        RegexOption.IGNORE_CASE
    )
    private val DICE_REGEX = Regex(
        "^(?:lance[rz]?\\s+un\\s+d[ée]|dé)\\s*(?:à\\s*)?([0-9]{1,3})?\\s*(?:faces?)?\\s*\\??$",
        RegexOption.IGNORE_CASE
    )
    private val RANDOM_RANGE_REGEX = Regex(
        "^nombre\\s+al[ée]atoire\\s+entre\\s+([0-9]+)\\s+et\\s+([0-9]+)\\s*\\??$",
        RegexOption.IGNORE_CASE
    )

    private fun randomAnswer(input: String): Answer? {
        if (COIN_FLIP_REGEX.matches(input)) {
            val result = if (kotlin.random.Random.nextBoolean()) "Pile 🙂" else "Face"
            return Answer("Pile ou face", result)
        }
        DICE_REGEX.matchEntire(input)?.let { match ->
            val faces = match.groupValues[1].toIntOrNull()?.coerceIn(2, 1000) ?: 6
            val roll = kotlin.random.Random.nextInt(1, faces + 1)
            return Answer("Dé à $faces faces", "$roll")
        }
        RANDOM_RANGE_REGEX.matchEntire(input)?.let { match ->
            val low = match.groupValues[1].toIntOrNull() ?: return null
            val high = match.groupValues[2].toIntOrNull() ?: return null
            if (low > high) return null
            val result = kotlin.random.Random.nextInt(low, high + 1)
            return Answer("Nombre aléatoire entre $low et $high", "$result")
        }
        return null
    }

    // -----------------------------------------------------------------
    // Date et heure locales (calculées sur l'appareil, aucun réseau)
    // -----------------------------------------------------------------

    private val TIME_REGEX = Regex(
        "^quelle\\s+heure\\s+est[- ]il\\s*\\??$",
        RegexOption.IGNORE_CASE
    )
    private val DATE_REGEX = Regex(
        "^(?:quel\\s+jour\\s+(?:sommes[- ]nous|on\\s+est)|date\\s+du\\s+jour|" +
            "quelle\\s+est\\s+la\\s+date(?:\\s+d'aujourd'hui)?|on\\s+est\\s+quel\\s+jour)\\s*\\??$",
        RegexOption.IGNORE_CASE
    )

    private fun dateTimeAnswer(input: String): Answer? {
        val now = java.util.Calendar.getInstance()
        if (TIME_REGEX.matches(input)) {
            val time = String.format(Locale.FRANCE, "%02d:%02d", now.get(java.util.Calendar.HOUR_OF_DAY), now.get(java.util.Calendar.MINUTE))
            return Answer("Heure actuelle", time)
        }
        if (DATE_REGEX.matches(input)) {
            val formatter = java.text.SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE)
            val formatted = formatter.format(now.time).replaceFirstChar { it.uppercase() }
            return Answer("Date d'aujourd'hui", formatted)
        }
        return null
    }
}
