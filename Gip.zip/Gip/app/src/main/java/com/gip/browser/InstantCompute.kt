package com.gip.browser

import java.util.Locale
import kotlin.math.pow

/**
 * Réponses instantanées calculées entièrement en local (aucune requête
 * réseau) : calculs arithmétiques et conversions d'unités courantes. Résultat
 * affiché avant même que les résultats web n'arrivent.
 */
object InstantCompute {

    data class Answer(val expression: String, val result: String)

    fun compute(query: String): Answer? {
        val trimmed = query.trim()
        conversion(trimmed)?.let { return it }
        return arithmetic(trimmed)
    }

    // -----------------------------------------------------------------
    // Calculatrice : expressions du type "12 * (4 + 2) / 3"
    // -----------------------------------------------------------------

    private fun arithmetic(input: String): Answer? {
        // N'accepte que des caractères de calcul : évite de tenter d'évaluer
        // une requête texte ordinaire ("comment ça va" etc.)
        val cleaned = input.replace(",", ".").replace(" ", "")
        if (cleaned.isBlank()) return null
        if (!cleaned.matches(Regex("^[0-9+\\-*/^().]+$"))) return null
        // Il faut au moins un opérateur pour ne pas "calculer" un simple nombre tapé seul.
        if (!cleaned.any { it in "+-*/^" } || cleaned.count { it.isDigit() } == 0) return null
        return try {
            val value = ExpressionParser(cleaned).parse()
            val formatted = if (value == value.toLong().toDouble()) {
                value.toLong().toString()
            } else {
                String.format(Locale.FRANCE, "%.6f", value).trimEnd('0').trimEnd(',')
            }
            Answer(input.trim(), formatted)
        } catch (e: Exception) {
            null
        }
    }

    /** Petit parseur récursif descendant : + - * / ^ () et nombres décimaux. */
    private class ExpressionParser(private val text: String) {
        private var pos = 0

        fun parse(): Double {
            val value = parseExpr()
            if (pos != text.length) throw IllegalArgumentException("Expression invalide")
            return value
        }

        private fun parseExpr(): Double {
            var value = parseTerm()
            while (pos < text.length && (text[pos] == '+' || text[pos] == '-')) {
                val op = text[pos++]
                val rhs = parseTerm()
                value = if (op == '+') value + rhs else value - rhs
            }
            return value
        }

        private fun parseTerm(): Double {
            var value = parseFactor()
            while (pos < text.length && (text[pos] == '*' || text[pos] == '/')) {
                val op = text[pos++]
                val rhs = parseFactor()
                value = if (op == '*') value * rhs else value / rhs
            }
            return value
        }

        private fun parseFactor(): Double {
            var value = parseUnary()
            if (pos < text.length && text[pos] == '^') {
                pos++
                val exponent = parseFactor()
                value = value.pow(exponent)
            }
            return value
        }

        private fun parseUnary(): Double {
            if (pos < text.length && text[pos] == '-') {
                pos++
                return -parseUnary()
            }
            return parseAtom()
        }

        private fun parseAtom(): Double {
            if (pos < text.length && text[pos] == '(') {
                pos++
                val value = parseExpr()
                if (pos >= text.length || text[pos] != ')') throw IllegalArgumentException("Parenthèse manquante")
                pos++
                return value
            }
            val start = pos
            while (pos < text.length && (text[pos].isDigit() || text[pos] == '.')) pos++
            if (start == pos) throw IllegalArgumentException("Nombre attendu")
            return text.substring(start, pos).toDouble()
        }
    }

    // -----------------------------------------------------------------
    // Conversions : "10 km en miles", "20 c en f", "5 kg en lb"
    // -----------------------------------------------------------------

    private val CONVERSIONS: Map<Pair<String, String>, (Double) -> Double> = mapOf(
        ("km" to "mi") to { v -> v * 0.621371 },
        ("mi" to "km") to { v -> v / 0.621371 },
        ("m" to "ft") to { v -> v * 3.28084 },
        ("ft" to "m") to { v -> v / 3.28084 },
        ("kg" to "lb") to { v -> v * 2.20462 },
        ("lb" to "kg") to { v -> v / 2.20462 },
        ("g" to "oz") to { v -> v * 0.035274 },
        ("oz" to "g") to { v -> v / 0.035274 },
        ("l" to "gal") to { v -> v * 0.264172 },
        ("gal" to "l") to { v -> v / 0.264172 },
        ("c" to "f") to { v -> v * 9.0 / 5.0 + 32 },
        ("f" to "c") to { v -> (v - 32) * 5.0 / 9.0 }
    )

    private val UNIT_LABELS = mapOf(
        "km" to "km", "mi" to "miles", "m" to "m", "ft" to "pieds",
        "kg" to "kg", "lb" to "livres", "g" to "g", "oz" to "oz",
        "l" to "litres", "gal" to "gallons", "c" to "°C", "f" to "°F"
    )

    private val CONVERSION_REGEX = Regex(
        "^([0-9]+(?:[.,][0-9]+)?)\\s*([a-zA-Z°]+)\\s+(?:en|to|in)\\s+([a-zA-Z°]+)$",
        RegexOption.IGNORE_CASE
    )

    private fun conversion(input: String): Answer? {
        val match = CONVERSION_REGEX.matchEntire(input.trim()) ?: return null
        val value = match.groupValues[1].replace(",", ".").toDoubleOrNull() ?: return null
        val from = match.groupValues[2].lowercase().removePrefix("°")
        val to = match.groupValues[3].lowercase().removePrefix("°")
        val fn = CONVERSIONS[from to to] ?: return null
        val result = fn(value)
        val formatted = String.format(Locale.FRANCE, "%.3f", result).trimEnd('0').trimEnd(',')
        val fromLabel = UNIT_LABELS[from] ?: from
        val toLabel = UNIT_LABELS[to] ?: to
        return Answer("$value $fromLabel", "$formatted $toLabel")
    }
}
