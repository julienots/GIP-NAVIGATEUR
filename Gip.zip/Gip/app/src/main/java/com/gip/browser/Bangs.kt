package com.gip.browser

import android.net.Uri

/**
 * "Bangs" façon DuckDuckGo : taper "!yt clash royale" ouvre directement
 * YouTube au lieu de passer par Gip Search. Purement local (pas de requête
 * réseau pour la résolution), et transparent pour l'utilisateur : la requête
 * démarre toujours par la barre d'adresse ou l'écran Gip Search comme
 * d'habitude.
 */
object Bangs {

    // clé -> modèle d'URL (%s = requête restante, déjà URL-encodée)
    private val MAP = mapOf(
        "w" to "https://fr.wikipedia.org/wiki/Special:Search?search=%s",
        "wiki" to "https://fr.wikipedia.org/wiki/Special:Search?search=%s",
        "yt" to "https://www.youtube.com/results?search_query=%s",
        "youtube" to "https://www.youtube.com/results?search_query=%s",
        "gh" to "https://github.com/search?q=%s",
        "github" to "https://github.com/search?q=%s",
        "so" to "https://stackoverflow.com/search?q=%s",
        "maps" to "https://www.google.com/maps/search/%s",
        "img" to "https://duckduckgo.com/?q=%s&iax=images&ia=images",
        "amz" to "https://www.amazon.fr/s?k=%s",
        "amazon" to "https://www.amazon.fr/s?k=%s",
        "tr" to "https://translate.google.com/?sl=auto&tl=fr&text=%s",
        "reddit" to "https://www.reddit.com/search/?q=%s",
        "news" to "https://news.google.com/search?q=%s&hl=fr",
        "g" to "https://www.google.com/search?q=%s",
        "ddg" to "https://duckduckgo.com/?q=%s"
    )

    /**
     * Si [input] commence par "!bang requête", renvoie l'URL de destination.
     * Renvoie null si aucun bang reconnu (auquel cas la recherche continue
     * normalement).
     */
    fun resolve(input: String): String? {
        val trimmed = input.trim()
        if (!trimmed.startsWith("!")) return null
        val spaceIndex = trimmed.indexOf(' ')
        val key = (if (spaceIndex == -1) trimmed.substring(1) else trimmed.substring(1, spaceIndex)).lowercase()
        val rest = if (spaceIndex == -1) "" else trimmed.substring(spaceIndex + 1).trim()
        val template = MAP[key] ?: return null
        return template.replace("%s", Uri.encode(rest))
    }

    /** Utilisé pour afficher un indice "!yt → YouTube" pendant la frappe. */
    fun hintFor(input: String): String? {
        val trimmed = input.trim()
        if (!trimmed.startsWith("!")) return null
        val key = trimmed.substring(1).substringBefore(' ').lowercase()
        return when (key) {
            "w", "wiki" -> "Wikipédia"
            "yt", "youtube" -> "YouTube"
            "gh", "github" -> "GitHub"
            "so" -> "Stack Overflow"
            "maps" -> "Google Maps"
            "img" -> "Images"
            "amz", "amazon" -> "Amazon"
            "tr" -> "Traduction"
            "reddit" -> "Reddit"
            "news" -> "Google Actualités"
            "g" -> "Google"
            "ddg" -> "DuckDuckGo"
            else -> null
        }
    }
}
