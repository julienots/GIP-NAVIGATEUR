package com.gip.browser

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.util.regex.Pattern

/**
 * Inspecteur HTML intégré à Gip.
 *
 * Ceci est un inspecteur "léger" pensé pour consulter rapidement le code
 * d'une page sans avoir besoin d'un ordinateur. Ce n'est PAS une réplique
 * complète des DevTools Chrome (pas de panneau Réseau, pas de console JS
 * live, pas d'édition en direct du DOM) : recréer ça dans une appli mobile
 * serait un chantier énorme et peu fiable. Pour une inspection complète
 * "comme sur PC", Gip active déjà le vrai débogage distant WebView
 * (MainActivity.onCreate) : brancher le téléphone en USB et ouvrir
 * chrome://inspect sur un ordinateur donne accès aux DevTools Chrome
 * complets sur les pages ouvertes ici.
 */
class InspectorActivity : AppCompatActivity() {

    private val tagColor = Color.parseColor("#00D9C0")
    private val stringColor = Color.parseColor("#FFB86C")
    private val commentColor = Color.parseColor("#6B7280")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inspector)

        val pageUrl = intent.getStringExtra("page_url").orEmpty()
        val sourcePath = intent.getStringExtra("source_path")
        val infoJson = intent.getStringExtra("page_info")

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<TextView>(R.id.pageUrlLabel).text = pageUrl

        val sourceText = findViewById<TextView>(R.id.sourceText)
        val elementsPanel = findViewById<View>(R.id.elementsPanel)
        val infoPanel = findViewById<View>(R.id.infoPanel)
        val tabElements = findViewById<TextView>(R.id.tabElements)
        val tabInfo = findViewById<TextView>(R.id.tabInfo)
        val infoContainer = findViewById<LinearLayout>(R.id.infoContainer)
        val btnCopy = findViewById<TextView>(R.id.btnCopy)

        val rawHtml = try {
            sourcePath?.let { File(it).readText() }.orEmpty()
        } catch (e: Exception) {
            ""
        }

        val truncated = rawHtml.length > MAX_CHARS
        val displayHtml = if (truncated) rawHtml.substring(0, MAX_CHARS) else rawHtml
        val pretty = prettyPrint(displayHtml) + if (truncated) "\n\n<!-- … code tronqué (page trop volumineuse) … -->" else ""
        sourceText.text = highlightHtml(pretty)

        btnCopy.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Code source", rawHtml))
            Toast.makeText(this, "Code source copié", Toast.LENGTH_SHORT).show()
        }

        tabElements.setOnClickListener {
            tabElements.setBackgroundResource(R.drawable.bg_tab_active)
            tabElements.setTextColor(ContextCompat.getColor(this, R.color.gip_text))
            tabInfo.setBackgroundResource(R.drawable.bg_tab_inactive)
            tabInfo.setTextColor(ContextCompat.getColor(this, R.color.gip_text_dim))
            elementsPanel.visibility = View.VISIBLE
            infoPanel.visibility = View.GONE
        }

        tabInfo.setOnClickListener {
            tabInfo.setBackgroundResource(R.drawable.bg_tab_active)
            tabInfo.setTextColor(ContextCompat.getColor(this, R.color.gip_text))
            tabElements.setBackgroundResource(R.drawable.bg_tab_inactive)
            tabElements.setTextColor(ContextCompat.getColor(this, R.color.gip_text_dim))
            elementsPanel.visibility = View.GONE
            infoPanel.visibility = View.VISIBLE
        }

        buildInfoPanel(infoContainer, pageUrl, infoJson)
    }

    private fun buildInfoPanel(container: LinearLayout, pageUrl: String, infoJson: String?) {
        val info = try {
            if (infoJson != null) JSONObject(infoJson) else JSONObject()
        } catch (e: Exception) {
            JSONObject()
        }
        val host = try { Uri.parse(pageUrl).host } catch (e: Exception) { null }

        addInfoRow(container, "Adresse", pageUrl)
        addInfoRow(container, "Domaine", host ?: "—")
        addInfoRow(container, "Titre", info.optString("title", "—"))
        addInfoRow(container, "Type de document", info.optString("doctype").ifBlank { "—" })
        addInfoRow(container, "Encodage", info.optString("charset").ifBlank { "—" })
        addInfoRow(container, "Scripts (<script>)", info.optInt("scripts", 0).toString())
        addInfoRow(container, "Images (<img>)", info.optInt("images", 0).toString())
        addInfoRow(container, "Liens (<a>)", info.optInt("links", 0).toString())
        addInfoRow(container, "Formulaires", info.optInt("forms", 0).toString())
        addInfoRow(container, "Balises <meta>", info.optInt("metas", 0).toString())
    }

    private fun addInfoRow(container: LinearLayout, label: String, value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val padding = (12 * resources.displayMetrics.density).toInt()
            setPadding(0, padding, 0, padding)
        }
        val labelView = TextView(this).apply {
            text = label
            setTextColor(ContextCompat.getColor(this@InspectorActivity, R.color.gip_text_dim))
            textSize = 11f
        }
        val valueView = TextView(this).apply {
            text = value
            setTextColor(ContextCompat.getColor(this@InspectorActivity, R.color.gip_text))
            textSize = 14f
            setPadding(0, (4 * resources.displayMetrics.density).toInt(), 0, 0)
        }
        row.addView(labelView)
        row.addView(valueView)
        container.addView(row)

        val divider = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
            setBackgroundColor(ContextCompat.getColor(this@InspectorActivity, R.color.gip_bar_bg))
        }
        container.addView(divider)
    }

    /**
     * Découpe grossièrement le HTML brut (souvent sur une seule ligne) en
     * lignes indentées selon la profondeur des balises, pour un rendu proche
     * de ce qu'affiche un panneau "Éléments" de bureau.
     */
    private fun prettyPrint(html: String): String {
        val spaced = html.replace(Regex(">\\s*<"), ">\n<")
        val voidTags = setOf(
            "area", "base", "br", "col", "embed", "hr", "img", "input",
            "link", "meta", "param", "source", "track", "wbr"
        )
        var depth = 0
        val sb = StringBuilder()
        for (rawLine in spaced.split("\n")) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue
            val isClosing = line.startsWith("</")
            val isSelfClosing = line.endsWith("/>")
            val isDoctypeOrComment = line.startsWith("<!")
            val isOpening = line.startsWith("<") && !isClosing && !isSelfClosing && !isDoctypeOrComment
            val tagName = Regex("^<([a-zA-Z0-9]+)").find(line)?.groupValues?.get(1)?.lowercase()
            val opensAndClosesSameTag = tagName != null && line.contains("</$tagName>")

            if (isClosing) depth = (depth - 1).coerceAtLeast(0)
            sb.append("  ".repeat(depth)).append(line).append('\n')
            if (isOpening && tagName != null && tagName !in voidTags && !opensAndClosesSameTag) depth++
        }
        return sb.toString()
    }

    /** Colore les balises et les valeurs d'attributs, comme un panneau "Éléments" de bureau. */
    private fun highlightHtml(source: String): SpannableStringBuilder {
        val builder = SpannableStringBuilder(source)
        val tagPattern = Pattern.compile("<!--.*?-->|</?[a-zA-Z!][^<>]*>", Pattern.DOTALL)
        val matcher = tagPattern.matcher(source)
        while (matcher.find()) {
            val start = matcher.start()
            val end = matcher.end()
            val tagText = source.substring(start, end)
            val isComment = tagText.startsWith("<!--")
            builder.setSpan(
                ForegroundColorSpan(if (isComment) commentColor else tagColor),
                start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            if (!isComment) {
                val attrMatcher = Pattern.compile("\"[^\"]*\"|'[^']*'").matcher(tagText)
                while (attrMatcher.find()) {
                    builder.setSpan(
                        ForegroundColorSpan(stringColor),
                        start + attrMatcher.start(), start + attrMatcher.end(),
                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                }
            }
        }
        return builder
    }

    companion object {
        private const val MAX_CHARS = 300_000
    }
}
