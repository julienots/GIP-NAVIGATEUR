package com.gip.browser

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.gip.browser.databinding.ActivityBookmarksBinding
import com.gip.browser.databinding.ItemLinkRowBinding

class BookmarksActivity : GipActivity() {

    private lateinit var binding: ActivityBookmarksBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: BookmarkAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBookmarksBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = DbHelper(this)

        adapter = BookmarkAdapter(this, mutableListOf())
        binding.listView.adapter = adapter

        binding.btnBack.setOnClickListener { finish() }

        binding.listView.setOnItemClickListener { _, _, position, _ ->
            val entry = adapter.getItem(position) ?: return@setOnItemClickListener
            val intent = Intent().putExtra("open_url", entry.url)
            setResult(RESULT_OK, intent)
            finish()
        }

        binding.listView.setOnItemLongClickListener { _, _, position, _ ->
            val entry = adapter.getItem(position) ?: return@setOnItemLongClickListener true
            AlertDialog.Builder(this)
                .setTitle("Supprimer ce favori ?")
                .setMessage(entry.url)
                .setPositiveButton("Supprimer") { _, _ ->
                    db.deleteBookmark(entry.id)
                    loadBookmarks()
                }
                .setNegativeButton("Annuler", null)
                .show()
            true
        }

        loadBookmarks()
    }

    override fun onResume() {
        super.onResume()
        loadBookmarks()
    }

    private fun loadBookmarks() {
        val entries = db.getBookmarks()
        adapter.replaceAll(entries)
        binding.emptyText.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
    }
}

class BookmarkAdapter(
    context: AppCompatActivity,
    private var items: MutableList<BookmarkEntry>
) : ArrayAdapter<BookmarkEntry>(context, 0, items) {

    fun replaceAll(newItems: List<BookmarkEntry>) {
        items = newItems.toMutableList()
        clear()
        addAll(items)
        notifyDataSetChanged()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val binding = if (convertView == null) {
            ItemLinkRowBinding.inflate(LayoutInflater.from(context), parent, false)
        } else {
            ItemLinkRowBinding.bind(convertView)
        }
        val entry = getItem(position)
        if (entry != null) {
            binding.rowTitle.text = entry.title.ifBlank { entry.url }
            binding.rowUrl.text = entry.url
        }
        return binding.root
    }
}
