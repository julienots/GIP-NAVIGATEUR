package com.gip.browser

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.text.Spannable
import android.text.SpannableString
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.model.GlideUrl
import com.bumptech.glide.load.model.LazyHeaders
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.gip.browser.databinding.ActivityGipSearchBinding
import com.gip.browser.databinding.FooterLoadMoreBinding
import com.gip.browser.databinding.HeaderGipSearchBinding
import com.gip.browser.databinding.ItemImageResultBinding
import com.gip.browser.databinding.ItemSearchResultBinding

/**
 * Écran de résultats de "Gip Search".
 *
 * Cet écran ne charge JAMAIS une page web de moteur tiers : il affiche
 * uniquement des vues natives dessinées par Gip, à partir de données brutes
 * récupérées et parsées par [GipSearchClient]. Aucun script, aucune pub,
 * aucun traceur d'un moteur de recherche ne peut donc s'exécuter ici.
 *
 * Deux catégories : Web (liste, avec pagination "Voir plus") et Images
 * (grille, source Openverse). L'importance visuelle des résultats est rendue
 * par la graisse du texte : titre toujours en gras, termes de la recherche
 * mis en gras dans le titre et l'extrait, reste en graisse normale.
 */
class GipSearchActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGipSearchBinding
    private lateinit var header: HeaderGipSearchBinding
    private lateinit var footer: FooterLoadMoreBinding
    private lateinit var db: DbHelper
    private lateinit var webAdapter: WebResultAdapter
    private lateinit var imageAdapter: ImageResultAdapter

    private var currentQuery: String = ""
    private var currentResponse: GipSearchClient.SearchResponse? = null
    private var isLoadingMore = false
    private var imagesLoadedFor: String? = null
    private var showingImages = false
    private var imagesNextPage = 2
    private var isLoadingMoreImages = false

    private lateinit var suggestionAdapter: ArrayAdapter<String>
    private val suggestionHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var suggestionRunnable: Runnable? = null

    private val voiceLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                binding.searchQuery.setText(spoken)
                runSearch(spoken)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGipSearchBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = DbHelper(this)

        header = HeaderGipSearchBinding.inflate(LayoutInflater.from(this), binding.resultsList, false)
        footer = FooterLoadMoreBinding.inflate(LayoutInflater.from(this), binding.resultsList, false)
        binding.resultsList.addHeaderView(header.root, null, false)
        binding.resultsList.addFooterView(footer.root, null, false)
        footer.root.visibility = View.GONE

        binding.btnLoadMoreImages.setOnClickListener { loadMoreImages() }

        webAdapter = WebResultAdapter(this, mutableListOf()) { currentQuery }
        binding.resultsList.adapter = webAdapter

        imageAdapter = ImageResultAdapter(this, mutableListOf())
        binding.imagesGrid.adapter = imageAdapter

        binding.btnBack.setOnClickListener { finish() }
        binding.btnMic.setOnClickListener { launchVoiceSearch() }
        binding.btnRetry.setOnClickListener { binding.searchQuery.text?.toString()?.let { runSearch(it) } }

        updateSafeSearchChip()
        binding.chipSafeSearch.setOnClickListener {
            Prefs.setSafeSearchEnabled(this, !Prefs.isSafeSearchEnabled(this))
            updateSafeSearchChip()
            runSearch(currentQuery)
        }

        binding.tabWeb.setOnClickListener { showWebTab() }
        binding.tabImages.setOnClickListener { showImagesTab() }

        binding.searchQuery.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                hideSuggestions()
                runSearch(binding.searchQuery.text.toString())
                true
            } else {
                false
            }
        }

        setupSuggestions()

        binding.resultsList.setOnItemClickListener { _, _, position, _ ->
            // position 0 = header, donc on décale de -1 (le footer, lui, gère son propre clic)
            val item = webAdapter.getItem(position - 1) ?: return@setOnItemClickListener
            openUrl(item.url)
        }

        binding.imagesGrid.setOnItemClickListener { _, _, position, _ ->
            // La dernière ligne est le footer "Voir plus d'images" : jamais un résultat.
            if (position >= imageAdapter.count) return@setOnItemClickListener
            val item = imageAdapter.getItem(position) ?: return@setOnItemClickListener
            openUrl(item.sourceUrl)
        }

        header.instantAnswerCard.setOnClickListener {
            currentResponse?.instantAnswer?.sourceUrl?.let { openUrl(it) }
        }

        footer.btnLoadMore.setOnClickListener { loadMoreResults() }

        val query = intent.getStringExtra("query").orEmpty()
        binding.searchQuery.setText(query)
        if (query.isNotBlank()) runSearch(query)
    }

    // ---------------------------------------------------------------
    // Catégories Web / Images
    // ---------------------------------------------------------------

    private fun showWebTab() {
        if (!showingImages) return
        showingImages = false
        binding.tabWeb.setBackgroundResource(R.drawable.bg_tab_active)
        binding.tabWeb.setTextColor(getColorCompat(R.color.gip_text))
        binding.tabImages.setBackgroundResource(R.drawable.bg_tab_inactive)
        binding.tabImages.setTextColor(getColorCompat(R.color.gip_text_dim))
        binding.resultsList.visibility = View.VISIBLE
        binding.imagesContainer.visibility = View.GONE
    }

    private fun showImagesTab() {
        if (showingImages) return
        showingImages = true
        binding.tabImages.setBackgroundResource(R.drawable.bg_tab_active)
        binding.tabImages.setTextColor(getColorCompat(R.color.gip_text))
        binding.tabWeb.setBackgroundResource(R.drawable.bg_tab_inactive)
        binding.tabWeb.setTextColor(getColorCompat(R.color.gip_text_dim))
        binding.resultsList.visibility = View.GONE
        binding.imagesContainer.visibility = View.VISIBLE
        if (currentQuery.isNotBlank() && imagesLoadedFor != currentQuery) {
            loadImages(currentQuery)
        }
    }

    private fun getColorCompat(id: Int) = androidx.core.content.ContextCompat.getColor(this, id)

    private fun loadImages(query: String) {
        imageAdapter.replaceAll(emptyList())
        imagesNextPage = 2
        binding.imagesLoadMoreBar.visibility = View.GONE
        binding.loadingBar.visibility = View.VISIBLE
        GipSearchClient.searchImages(query) { outcome ->
            binding.loadingBar.visibility = View.GONE
            imagesLoadedFor = query
            outcome.onSuccess { images ->
                imageAdapter.replaceAll(images)
                binding.btnLoadMoreImages.text = "Voir plus d'images"
                binding.btnLoadMoreImages.isEnabled = true
                binding.imagesLoadMoreBar.visibility = if (images.isEmpty()) View.GONE else View.VISIBLE
            }
            outcome.onFailure {
                Toast.makeText(this, "Impossible de charger les images pour l'instant.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** Page suivante de la catégorie Images, pour le bouton "Voir plus d'images". */
    private fun loadMoreImages() {
        if (isLoadingMoreImages || currentQuery.isBlank()) return
        isLoadingMoreImages = true
        binding.btnLoadMoreImages.visibility = View.GONE
        binding.imagesLoadMoreProgress.visibility = View.VISIBLE

        GipSearchClient.searchMoreImages(currentQuery, imagesNextPage) { outcome ->
            isLoadingMoreImages = false
            binding.imagesLoadMoreProgress.visibility = View.GONE
            outcome.onSuccess { more ->
                if (more.isEmpty()) {
                    binding.btnLoadMoreImages.text = "Plus aucune image"
                    binding.btnLoadMoreImages.visibility = View.VISIBLE
                    binding.btnLoadMoreImages.isEnabled = false
                } else {
                    imageAdapter.append(more)
                    imagesNextPage += 1
                    binding.btnLoadMoreImages.visibility = View.VISIBLE
                }
            }
            outcome.onFailure {
                binding.btnLoadMoreImages.visibility = View.VISIBLE
                Toast.makeText(this, "Impossible de charger plus d'images.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------------------------------------------------------------

    private fun updateSafeSearchChip() {
        val enabled = Prefs.isSafeSearchEnabled(this)
        binding.chipSafeSearch.text = if (enabled) "🔒 Recherche sécurisée" else "🔓 Sans filtre"
        binding.chipSafeSearch.setBackgroundResource(
            if (enabled) R.drawable.bg_tab_active else R.drawable.bg_tab_inactive
        )
    }

    private fun launchVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Parlez pour rechercher avec Gip")
        }
        try {
            voiceLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Reconnaissance vocale indisponible sur cet appareil", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openUrl(url: String) {
        setResult(RESULT_OK, Intent().putExtra("open_url", url))
        finish()
    }

    // ---------------------------------------------------------------
    // Suggestions en direct (complétion + recherches Gip récentes)
    // ---------------------------------------------------------------

    private fun setupSuggestions() {
        suggestionAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        binding.suggestionsList.adapter = suggestionAdapter
        binding.suggestionsList.setOnItemClickListener { _, _, position, _ ->
            val chosen = suggestionAdapter.getItem(position) ?: return@setOnItemClickListener
            binding.searchQuery.setText(chosen)
            hideSuggestions()
            runSearch(chosen)
        }

        binding.searchQuery.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (!binding.searchQuery.hasFocus()) return
                scheduleSuggestions(s?.toString().orEmpty())
            }
        })
        binding.searchQuery.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) scheduleSuggestions(binding.searchQuery.text.toString()) else hideSuggestions()
        }
    }

    /** Débounce de 150ms pour ne pas spammer l'API de suggestions à chaque frappe. */
    private fun scheduleSuggestions(query: String) {
        suggestionRunnable?.let { suggestionHandler.removeCallbacks(it) }
        val bangHint = Bangs.hintFor(query)
        if (bangHint != null) {
            showSuggestionItems(listOf("$query  →  $bangHint"))
            return
        }
        if (query.isBlank()) {
            val recent = db.getRecentSearches(null, 6)
            if (recent.isNotEmpty()) showSuggestionItems(recent) else hideSuggestions()
            return
        }
        val runnable = Runnable {
            val recent = db.getRecentSearches(query, 3)
            GipSearchClient.suggest(query) { remote ->
                val merged = (recent + remote).distinct().take(8)
                if (merged.isNotEmpty()) showSuggestionItems(merged) else hideSuggestions()
            }
        }
        suggestionRunnable = runnable
        suggestionHandler.postDelayed(runnable, 150)
    }

    private fun showSuggestionItems(items: List<String>) {
        suggestionAdapter.clear()
        suggestionAdapter.addAll(items)
        suggestionAdapter.notifyDataSetChanged()
        binding.suggestionsList.visibility = View.VISIBLE
    }

    private fun hideSuggestions() {
        binding.suggestionsList.visibility = View.GONE
    }

    /**
     * Domaines "connus" de l'utilisateur (favoris + historique) : c'est ce qui
     * permet à Gip Search de repérer, uniquement en local, les sites que la
     * personne visite déjà souvent — un moteur classique ne peut pas le faire.
     */
    private fun knownDomains(): Set<String> {
        val hosts = mutableSetOf<String>()
        for (b in db.getBookmarks()) Uri.parse(b.url).host?.removePrefix("www.")?.let { hosts.add(it) }
        for (h in db.getHistory(null).take(300)) Uri.parse(h.url).host?.removePrefix("www.")?.let { hosts.add(it) }
        return hosts
    }

    private fun runSearch(query: String) {
        if (query.isBlank()) return
        hideSuggestions()

        // Bang ("!yt clash royale") : on saute Gip Search et on ouvre directement
        // le site visé dans l'onglet courant, comme sur DuckDuckGo.
        Bangs.resolve(query)?.let { url ->
            openUrl(url)
            return
        }

        db.addSearchQuery(query)
        currentQuery = query
        currentResponse = null
        imagesLoadedFor = null
        showWebTab()
        binding.loadingBar.visibility = View.VISIBLE
        binding.statusText.visibility = View.GONE
        binding.btnRetry.visibility = View.GONE
        footer.root.visibility = View.GONE
        header.instantAnswerCard.visibility = View.GONE
        header.computedAnswerCard.visibility = View.GONE
        header.relatedSearchesScroll.visibility = View.GONE
        header.resultsCountLabel.text = ""
        webAdapter.replaceAll(emptyList())

        val domains = knownDomains()
        GipSearchClient.search(query, Prefs.isSafeSearchEnabled(this), domains) { outcome ->
            binding.loadingBar.visibility = View.GONE
            outcome.onSuccess { response -> renderResponse(response) }
            outcome.onFailure { showError() }
        }
    }

    private fun loadMoreResults() {
        val response = currentResponse ?: return
        if (isLoadingMore) return
        isLoadingMore = true
        footer.btnLoadMore.visibility = View.GONE
        footer.loadMoreProgress.visibility = View.VISIBLE

        GipSearchClient.searchMore(
            currentQuery,
            Prefs.isSafeSearchEnabled(this),
            knownDomains(),
            response.nextOffset
        ) { outcome ->
            isLoadingMore = false
            footer.loadMoreProgress.visibility = View.GONE
            outcome.onSuccess { more ->
                if (more.isEmpty()) {
                    footer.btnLoadMore.text = "Plus aucun résultat"
                    footer.btnLoadMore.visibility = View.VISIBLE
                    footer.btnLoadMore.isEnabled = false
                } else {
                    webAdapter.append(more)
                    currentResponse = response.copy(
                        results = response.results + more,
                        nextOffset = response.nextOffset + 30
                    )
                    header.resultsCountLabel.text =
                        "${currentResponse!!.results.size} résultat(s) pour « $currentQuery »"
                    footer.btnLoadMore.visibility = View.VISIBLE
                }
            }
            outcome.onFailure {
                footer.btnLoadMore.visibility = View.VISIBLE
                Toast.makeText(this, "Impossible de charger plus de résultats.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun renderResponse(response: GipSearchClient.SearchResponse) {
        currentResponse = response

        val computed = response.computedAnswer
        if (computed != null) {
            header.computedAnswerCard.visibility = View.VISIBLE
            header.computedAnswerExpression.text = computed.expression
            header.computedAnswerResult.text = computed.result
        } else {
            header.computedAnswerCard.visibility = View.GONE
        }

        renderRelatedSearches(response.relatedSearches)

        val answer = response.instantAnswer
        if (answer != null) {
            header.instantAnswerCard.visibility = View.VISIBLE
            header.instantAnswerTitle.text = answer.title
            header.instantAnswerExtract.text = answer.extract
            if (answer.thumbnailUrl != null) {
                header.instantAnswerThumb.visibility = View.VISIBLE
                Glide.with(this).load(answer.thumbnailUrl).centerCrop().into(header.instantAnswerThumb)
            } else {
                header.instantAnswerThumb.visibility = View.GONE
            }
        } else {
            header.instantAnswerCard.visibility = View.GONE
        }

        if (response.results.isEmpty() && answer == null && computed == null) {
            showError(message = "Aucun résultat pour « ${response.query} ».")
            return
        }

        header.resultsCountLabel.text = if (response.results.isEmpty()) {
            ""
        } else {
            "${response.results.size} résultat(s) pour « ${response.query} »"
        }
        webAdapter.replaceAll(response.results)
        footer.btnLoadMore.text = "Voir plus de résultats"
        footer.btnLoadMore.isEnabled = true
        footer.root.visibility = if (response.results.isEmpty()) View.GONE else View.VISIBLE
        binding.noTrackerLabel.text = "🛡 0 traceur sur cette page — Gip ne charge rien d'un moteur tiers"
    }

    /** Puces de recherches associées, générées à partir des suggestions DuckDuckGo. */
    private fun renderRelatedSearches(related: List<String>) {
        header.relatedSearchesContainer.removeAllViews()
        if (related.isEmpty()) {
            header.relatedSearchesScroll.visibility = View.GONE
            return
        }
        for (term in related) {
            val chip = TextView(this).apply {
                text = term
                textSize = 12f
                setTextColor(getColorCompat(R.color.gip_text))
                setBackgroundResource(R.drawable.bg_tab_inactive)
                setPadding(28, 14, 28, 14)
                val params = ViewGroup.MarginLayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = 20 }
                layoutParams = params
                setOnClickListener {
                    binding.searchQuery.setText(term)
                    runSearch(term)
                }
            }
            header.relatedSearchesContainer.addView(chip)
        }
        header.relatedSearchesScroll.visibility = View.VISIBLE
    }

    private fun showError(message: String = "Impossible de contacter les sources de Gip Search.\nVérifiez votre connexion internet.") {
        binding.statusText.text = message
        binding.statusText.visibility = View.VISIBLE
        binding.btnRetry.visibility = View.VISIBLE
        footer.root.visibility = View.GONE
        header.computedAnswerCard.visibility = View.GONE
        header.relatedSearchesScroll.visibility = View.GONE
    }
}

/**
 * Met en gras les segments de [text] qui correspondent à un mot de [query]
 * (au moins 3 lettres, insensible à la casse). Le reste garde une graisse
 * normale : c'est ce qui matérialise "l'importance" d'un passage à l'écran.
 */
private fun highlight(text: String, query: String): CharSequence {
    if (query.isBlank()) return text
    val words = query.split(" ").map { it.trim() }.filter { it.length >= 3 }
    if (words.isEmpty()) return text
    val spannable = SpannableString(text)
    val lower = text.lowercase()
    for (word in words) {
        val needle = word.lowercase()
        var start = lower.indexOf(needle)
        while (start >= 0) {
            spannable.setSpan(
                StyleSpan(Typeface.BOLD),
                start,
                start + needle.length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            start = lower.indexOf(needle, start + needle.length)
        }
    }
    return spannable
}

private class WebResultAdapter(
    context: AppCompatActivity,
    private var items: MutableList<GipSearchClient.WebResult>,
    private val currentQuery: () -> String
) : ArrayAdapter<GipSearchClient.WebResult>(context, 0, items) {

    fun replaceAll(newItems: List<GipSearchClient.WebResult>) {
        items = newItems.toMutableList()
        clear()
        addAll(items)
        notifyDataSetChanged()
    }

    fun append(more: List<GipSearchClient.WebResult>) {
        items.addAll(more)
        addAll(more)
        notifyDataSetChanged()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val binding = if (convertView == null) {
            ItemSearchResultBinding.inflate(LayoutInflater.from(context), parent, false)
        } else {
            ItemSearchResultBinding.bind(convertView)
        }
        val item = getItem(position)
        if (item != null) {
            val host = try { Uri.parse(item.url).host?.removePrefix("www.") } catch (e: Exception) { null }
            val query = currentQuery()
            // Titre : toujours en gras (importance maximale, c'est le résultat).
            binding.resultTitle.text = SpannableString(item.title).apply {
                setSpan(StyleSpan(Typeface.BOLD), 0, length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            // Extrait : graisse normale, sauf les mots de la recherche mis en évidence.
            binding.resultSnippet.text = highlight(item.snippet, query)
            // Domaine : en gras seulement s'il s'agit d'un site que vous visitez déjà souvent.
            binding.resultDomain.text = if (item.isFrequentlyVisited) {
                SpannableString(host ?: item.url).apply {
                    setSpan(StyleSpan(Typeface.BOLD), 0, length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            } else {
                host ?: item.url
            }
            binding.resultBadge.visibility = if (item.isFrequentlyVisited) View.VISIBLE else View.GONE
        }
        return binding.root
    }
}

private class ImageResultAdapter(
    context: AppCompatActivity,
    private var items: MutableList<GipSearchClient.ImageResult>
) : ArrayAdapter<GipSearchClient.ImageResult>(context, 0, items) {

    fun replaceAll(newItems: List<GipSearchClient.ImageResult>) {
        items = newItems.toMutableList()
        clear()
        addAll(items)
        notifyDataSetChanged()
    }

    fun append(more: List<GipSearchClient.ImageResult>) {
        items.addAll(more)
        addAll(more)
        notifyDataSetChanged()
    }

    /**
     * Beaucoup d'hébergeurs d'images (Flickr, musées, Wikimedia...) refusent
     * de servir une image à qui ne se présente pas comme un vrai navigateur
     * venu d'une vraie page (protection anti-hotlinking) : sans ces deux
     * en-têtes, la requête est simplement rejetée et l'image reste vide,
     * sans qu'aucune erreur ne soit visible côté utilisateur.
     */
    private fun browserLikeUrl(url: String): GlideUrl = GlideUrl(
        url,
        LazyHeaders.Builder()
            .addHeader(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) " +
                    "Chrome/125.0.0.0 Mobile Safari/537.36"
            )
            .addHeader("Referer", "https://openverse.org/")
            .addHeader("Accept", "image/avif,image/webp,image/*,*/*;q=0.8")
            .build()
    )

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val binding = if (convertView == null) {
            ItemImageResultBinding.inflate(LayoutInflater.from(context), parent, false)
        } else {
            ItemImageResultBinding.bind(convertView)
        }
        val item = getItem(position)
        if (item != null) {
            loadThumbnail(binding, item)
            // Un tap sur une case en échec relance le chargement (utile après
            // une coupure réseau passagère) plutôt que de rester bloquée en erreur.
            binding.imageThumb.setOnClickListener {
                if (binding.imageThumb.tag == TAG_FAILED) loadThumbnail(binding, item, forceRetry = true)
            }
        }
        return binding.root
    }

    private fun loadThumbnail(
        binding: ItemImageResultBinding,
        item: GipSearchClient.ImageResult,
        forceRetry: Boolean = false
    ) {
        binding.imageThumb.tag = TAG_LOADING
        binding.imageThumb.setImageDrawable(null)

        fun withRetryOptions(url: String) = Glide.with(context).load(browserLikeUrl(url)).centerCrop().apply {
            diskCacheStrategy(if (forceRetry) DiskCacheStrategy.NONE else DiskCacheStrategy.ALL)
            if (forceRetry) skipMemoryCache(true)
        }

        // Le proxy de vignette Openverse est fiable, mais si jamais il échoue
        // (image supprimée côté fournisseur, délai dépassé...), on retente une
        // dernière fois avec l'URL brute plutôt que de laisser une case vide.
        val fallback = withRetryOptions(item.fallbackThumbnailUrl)
            .error(R.drawable.ic_image_broken)
            .listener(object : RequestListener<android.graphics.drawable.Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<android.graphics.drawable.Drawable>,
                    isFirstResource: Boolean
                ): Boolean {
                    binding.imageThumb.tag = TAG_FAILED
                    return false
                }

                override fun onResourceReady(
                    resource: android.graphics.drawable.Drawable,
                    model: Any,
                    target: Target<android.graphics.drawable.Drawable>?,
                    dataSource: DataSource,
                    isFirstResource: Boolean
                ): Boolean {
                    binding.imageThumb.tag = TAG_LOADED
                    return false
                }
            })

        withRetryOptions(item.thumbnailUrl)
            .listener(object : RequestListener<android.graphics.drawable.Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<android.graphics.drawable.Drawable>,
                    isFirstResource: Boolean
                ): Boolean {
                    if (item.thumbnailUrl != item.fallbackThumbnailUrl) {
                        fallback.into(binding.imageThumb)
                    } else {
                        binding.imageThumb.tag = TAG_FAILED
                    }
                    return item.thumbnailUrl != item.fallbackThumbnailUrl
                }

                override fun onResourceReady(
                    resource: android.graphics.drawable.Drawable,
                    model: Any,
                    target: Target<android.graphics.drawable.Drawable>?,
                    dataSource: DataSource,
                    isFirstResource: Boolean
                ): Boolean {
                    binding.imageThumb.tag = TAG_LOADED
                    return false
                }
            })
            .into(binding.imageThumb)
    }

    companion object {
        private const val TAG_LOADING = "loading"
        private const val TAG_LOADED = "loaded"
        private const val TAG_FAILED = "failed"
    }
}
