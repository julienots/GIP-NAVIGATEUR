package com.gip.browser

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.gip.browser.databinding.ActivityGipSearchBinding
import com.gip.browser.databinding.HeaderGipSearchBinding
import com.gip.browser.databinding.ItemSearchResultBinding

/**
 * Écran de résultats de "Gip Search".
 *
 * Cet écran ne charge JAMAIS une page web de moteur tiers : il affiche
 * uniquement des vues natives dessinées par Gip, à partir de données brutes
 * récupérées et parsées par [GipSearchClient]. Aucun script, aucune pub,
 * aucun traceur d'un moteur de recherche ne peut donc s'exécuter ici.
 */
class GipSearchActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGipSearchBinding
    private lateinit var header: HeaderGipSearchBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: ResultAdapter

    private var currentResponse: GipSearchClient.SearchResponse? = null

    private val voiceLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                binding.searchQuery.setText(spoken)
                runSearch(spoken)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGipSearchBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = DbHelper(this)

        header = HeaderGipSearchBinding.inflate(LayoutInflater.from(this), binding.resultsList, false)
        binding.resultsList.addHeaderView(header.root, null, false)

        adapter = ResultAdapter(this, mutableListOf())
        binding.resultsList.adapter = adapter

        binding.btnBack.setOnClickListener { finish() }
        binding.btnMic.setOnClickListener { launchVoiceSearch() }
        binding.btnRetry.setOnClickListener { binding.searchQuery.text?.toString()?.let { runSearch(it) } }

        updateSafeSearchChip()
        binding.chipSafeSearch.setOnClickListener {
            Prefs.setSafeSearchEnabled(this, !Prefs.isSafeSearchEnabled(this))
            updateSafeSearchChip()
            binding.searchQuery.text?.toString()?.let { runSearch(it) }
        }

        binding.searchQuery.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runSearch(binding.searchQuery.text.toString())
                true
            } else {
                false
            }
        }

        binding.resultsList.setOnItemClickListener { _, _, position, _ ->
            // position 0 = header, donc on décale de -1
            val item = adapter.getItem(position - 1) ?: return@setOnItemClickListener
            openUrl(item.url)
        }

        header.instantAnswerCard.setOnClickListener {
            currentResponse?.instantAnswer?.sourceUrl?.let { openUrl(it) }
        }

        val query = intent.getStringExtra("query").orEmpty()
        binding.searchQuery.setText(query)
        if (query.isNotBlank()) runSearch(query)
    }

    private fun updateSafeSearchChip() {
        val enabled = Prefs.isSafeSearchEnabled(this)
        binding.chipSafeSearch.text = if (enabled) "🔒 Recherche sécurisée" else "🔓 Sans filtre"
        binding.chipSafeSearch.setBackgroundResource(
            if (enabled) R.drawable.bg_tab_active else R.drawable.bg_tab_inactive
        )
    }

    private fun launchVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Parlez pour rechercher avec Gip")
        }
        try {
            voiceLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Reconnaissance vocale indisponible sur cet appareil", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openUrl(url: String) {
        setResult(RESULT_OK, Intent().putExtra("open_url", url))
        finish()
    }

    /**
     * Domaines "connus" de l'utilisateur (favoris + historique) : c'est ce qui
     * permet à Gip Search de repérer, uniquement en local, les sites que la
     * personne visite déjà souvent — un moteur classique ne peut pas le faire.
     */
    private fun knownDomains(): Set<String> {
        val hosts = mutableSetOf<String>()
        for (b in db.getBookmarks()) Uri.parse(b.url).host?.removePrefix("www.")?.let { hosts.add(it) }
        for (h in db.getHistory(null).take(300)) Uri.parse(h.url).host?.removePrefix("www.")?.let { hosts.add(it) }
        return hosts
    }

    private fun runSearch(query: String) {
        if (query.isBlank()) return
        currentResponse = null
        binding.loadingBar.visibility = View.VISIBLE
        binding.statusText.visibility = View.GONE
        binding.btnRetry.visibility = View.GONE
        header.instantAnswerCard.visibility = View.GONE
        header.resultsCountLabel.text = ""
        adapter.replaceAll(emptyList())

        val domains = knownDomains()
        GipSearchClient.search(query, Prefs.isSafeSearchEnabled(this), domains) { outcome ->
            binding.loadingBar.visibility = View.GONE
            outcome.onSuccess { response -> renderResponse(response) }
            outcome.onFailure { showError() }
        }
    }

    private fun renderResponse(response: GipSearchClient.SearchResponse) {
        currentResponse = response

        val answer = response.instantAnswer
        if (answer != null) {
            header.instantAnswerCard.visibility = View.VISIBLE
            header.instantAnswerTitle.text = answer.title
            header.instantAnswerExtract.text = answer.extract
        } else {
            header.instantAnswerCard.visibility = View.GONE
        }

        if (response.results.isEmpty() && answer == null) {
            showError(message = "Aucun résultat pour « ${response.query} ».")
            return
        }

        header.resultsCountLabel.text = if (response.results.isEmpty()) {
            ""
        } else {
            "${response.results.size} résultat(s) pour « ${response.query} »"
        }
        adapter.replaceAll(response.results)
        binding.noTrackerLabel.text = "🛡 0 traceur sur cette page — Gip ne charge rien d'un moteur tiers"
    }

    private fun showError(message: String = "Impossible de contacter les sources de Gip Search.\nVérifiez votre connexion internet.") {
        binding.statusText.text = message
        binding.statusText.visibility = View.VISIBLE
        binding.btnRetry.visibility = View.VISIBLE
    }
}

private class ResultAdapter(
    context: AppCompatActivity,
    private var items: MutableList<GipSearchClient.WebResult>
) : ArrayAdapter<GipSearchClient.WebResult>(context, 0, items) {

    fun replaceAll(newItems: List<GipSearchClient.WebResult>) {
        items = newItems.toMutableList()
        clear()
        addAll(items)
        notifyDataSetChanged()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val binding = if (convertView == null) {
            ItemSearchResultBinding.inflate(LayoutInflater.from(context), parent, false)
        } else {
            ItemSearchResultBinding.bind(convertView)
        }
        val item = getItem(position)
        if (item != null) {
            val host = try { Uri.parse(item.url).host?.removePrefix("www.") } catch (e: Exception) { null }
            binding.resultDomain.text = host ?: item.url
            binding.resultTitle.text = item.title
            binding.resultSnippet.text = item.snippet
            binding.resultBadge.visibility = if (item.isFrequentlyVisited) View.VISIBLE else View.GONE
        }
        return binding.root
    }
}
