package com.gip.browser

import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * Deux nouveaux services "instantanés" affichés sous la marque Gip, sur le
 * même principe que le reste de Gip Search (voir GipSearchClient) : on
 * interroge en coulisses une source publique indépendante, sans clé, et on
 * affiche uniquement le résultat dans l'interface de Gip — jamais un pixel,
 * un logo ou une page de la source d'origine.
 *
 *  - Gip Météo : géocodage + prévisions Open-Meteo (service public européen,
 *    aucune clé requise).
 *  - Gip Devises : taux de change Frankfurter.app, adossé aux taux publiés
 *    par la Banque centrale européenne (aucune clé requise).
 *
 * Comme pour InstantCompute, ces fonctions renvoient `null` immédiatement
 * (sans requête réseau) si la requête ne correspond pas au bon format : une
 * recherche normale n'est donc jamais ralentie par ces essais.
 */
object GipInstantServices {

    data class WeatherAnswer(
        val place: String,
        val temperatureC: Double,
        val emoji: String,
        val description: String,
        val windKmh: Double
    )

    data class DictionaryAnswer(
        val word: String,
        val definition: String,
        val sourceUrl: String
    )

    // -----------------------------------------------------------------
    // Gip Météo
    // -----------------------------------------------------------------

    private val WEATHER_REGEX = Regex(
        "^(?:m[ée]t[ée]o|temps|quel temps fait[- ]il)\\s*(?:à|a|au|aux|en|pour|de|d')?\\s*(.{2,50})$",
        RegexOption.IGNORE_CASE
    )

    fun fetchWeather(query: String): WeatherAnswer? {
        val match = WEATHER_REGEX.matchEntire(query.trim()) ?: return null
        val city = match.groupValues[1].trim().trim('?', '.', '!', ' ')
        if (city.isBlank()) return null

        val encodedCity = URLEncoder.encode(city, "UTF-8")
        val geoJson = get(
            "https://geocoding-api.open-meteo.com/v1/search?name=$encodedCity&count=1&language=fr"
        )
        val place = JSONObject(geoJson).optJSONArray("results")?.optJSONObject(0) ?: return null
        val lat = place.optDouble("latitude")
        val lon = place.optDouble("longitude")
        if (lat.isNaN() || lon.isNaN()) return null
        val placeName = place.optString("name", city)
        val country = place.optString("country", "")

        val forecastJson = get(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current_weather=true"
        )
        val current = JSONObject(forecastJson).optJSONObject("current_weather") ?: return null
        val temperature = current.optDouble("temperature")
        val wind = current.optDouble("windspeed")
        if (temperature.isNaN()) return null
        val (emoji, description) = describeWeatherCode(current.optInt("weathercode", -1))

        val label = if (country.isNotBlank() && !placeName.equals(country, ignoreCase = true)) {
            "$placeName, $country"
        } else {
            placeName
        }
        return WeatherAnswer(label, temperature, emoji, description, wind)
    }

    /** Codes météo WMO (standard utilisé par Open-Meteo). */
    private fun describeWeatherCode(code: Int): Pair<String, String> = when (code) {
        0 -> "☀️" to "Ciel dégagé"
        1, 2 -> "🌤️" to "Peu nuageux"
        3 -> "☁️" to "Couvert"
        45, 48 -> "🌫️" to "Brouillard"
        51, 53, 55, 56, 57 -> "🌦️" to "Bruine"
        61, 63, 65, 66, 67 -> "🌧️" to "Pluie"
        71, 73, 75, 77 -> "🌨️" to "Neige"
        80, 81, 82 -> "🌦️" to "Averses"
        85, 86 -> "🌨️" to "Averses de neige"
        95 -> "⛈️" to "Orage"
        96, 99 -> "⛈️" to "Orage avec grêle"
        else -> "🌡️" to "Conditions variables"
    }

    // -----------------------------------------------------------------
    // Gip Devises
    // -----------------------------------------------------------------

    private val CURRENCY_NAMES = mapOf(
        "dollar" to "USD", "dollars" to "USD", "usd" to "USD",
        "euro" to "EUR", "euros" to "EUR", "eur" to "EUR",
        "livre" to "GBP", "livres" to "GBP", "gbp" to "GBP",
        "franc" to "CHF", "francs" to "CHF", "chf" to "CHF",
        "yen" to "JPY", "yens" to "JPY", "jpy" to "JPY",
        "cad" to "CAD", "aud" to "AUD"
    )

    private val CURRENCY_REGEX = Regex(
        "^([0-9]+(?:[.,][0-9]+)?)\\s*([a-zàâéèêëîïôûùüç]+)\\s+(?:en|to|contre)\\s+([a-zàâéèêëîïôûùüç]+)$",
        RegexOption.IGNORE_CASE
    )

    fun fetchCurrency(query: String): InstantCompute.Answer? {
        val match = CURRENCY_REGEX.matchEntire(query.trim()) ?: return null
        val amount = match.groupValues[1].replace(",", ".").toDoubleOrNull() ?: return null
        val from = CURRENCY_NAMES[match.groupValues[2].lowercase(Locale.ROOT)] ?: return null
        val to = CURRENCY_NAMES[match.groupValues[3].lowercase(Locale.ROOT)] ?: return null
        if (from == to) return null

        val json = get("https://api.frankfurter.app/latest?amount=$amount&from=$from&to=$to")
        val rate = JSONObject(json).optJSONObject("rates")?.optDouble(to) ?: return null
        if (rate.isNaN()) return null

        val formattedAmount = trimZeros(amount)
        val formattedResult = trimZeros(rate)
        return InstantCompute.Answer("$formattedAmount $from", "$formattedResult $to")
    }

    private fun trimZeros(value: Double): String {
        val formatted = String.format(Locale.FRANCE, "%.2f", value)
        return formatted.trimEnd('0').trimEnd(',')
    }

    // -----------------------------------------------------------------
    // Gip Dictionnaire
    // -----------------------------------------------------------------
    //
    // Source : API MediaWiki publique du Wiktionnaire francophone (même
    // principe que fr.wikipedia.org pour la réponse rapide), aucune clé
    // requise. On récupère l'extrait en texte brut de la page, qui commence
    // toujours par la ou les définitions du mot.

    private val DEFINITION_REGEX = Regex(
        "^(?:d[ée]finition\\s+(?:de|du|d')|que\\s+veut\\s+dire|que\\s+signifie|" +
            "c'est\\s+quoi|qu'est[- ]ce\\s+que)\\s+(.{1,50})$",
        RegexOption.IGNORE_CASE
    )

    fun fetchDefinition(query: String): DictionaryAnswer? {
        val trimmed = query.trim()
        val match = DEFINITION_REGEX.matchEntire(trimmed)
        val word = (match?.groupValues?.get(1) ?: trimmed.removePrefix("def:").removePrefix("def "))
            .trim()
            .trim('?', '.', '!', ' ')
        // "def:mot" est un raccourci volontairement plus court, mais une phrase
        // ordinaire (plusieurs mots sans motif reconnu) n'est pas une demande
        // de définition : on l'ignore pour ne pas gêner une recherche normale.
        if (word.isBlank() || (match == null && !trimmed.startsWith("def", ignoreCase = true))) return null
        if (word.contains(" ") && word.split(" ").size > 4) return null

        val encoded = URLEncoder.encode(word, "UTF-8")
        val json = get(
            "https://fr.wiktionary.org/w/api.php?action=query&prop=extracts&explaintext=1&" +
                "redirects=1&format=json&titles=$encoded"
        )
        val pages = JSONObject(json).optJSONObject("query")?.optJSONObject("pages") ?: return null
        val keys = pages.keys()
        if (!keys.hasNext()) return null
        val page = pages.optJSONObject(keys.next()) ?: return null
        if (page.has("missing")) return null
        val title = page.optString("title", word)
        val rawExtract = page.optString("extract").takeIf { it.isNotBlank() } ?: return null

        // L'extrait brut du Wiktionnaire liste toutes les langues et sections
        // (Étymologie, Prononciation...) : on garde seulement les premières
        // lignes utiles (définitions), assez courtes pour une carte de réponse
        // rapide plutôt qu'un article entier.
        val definition = rawExtract.lineSequence()
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("==") }
            .take(3)
            .joinToString(" ")
            .take(400)
            .takeIf { it.isNotBlank() } ?: return null

        return DictionaryAnswer(title, definition, "https://fr.wiktionary.org/wiki/${Uri.encode(title)}")
    }

    // -----------------------------------------------------------------
    // Utilitaire réseau (même profil que GipSearchClient.get)
    // -----------------------------------------------------------------

    private fun get(urlString: String): String {
        val connection = URL(urlString).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.setRequestProperty("User-Agent", "Gip/1.0")
        connection.connectTimeout = 8000
        connection.readTimeout = 8000
        connection.instanceFollowRedirects = true
        return try {
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
}
