package com.gip.browser

import android.content.Context
import com.bumptech.glide.Glide
import com.bumptech.glide.Registry
import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.integration.okhttp3.OkHttpUrlLoader
import com.bumptech.glide.load.model.GlideUrl
import com.bumptech.glide.module.AppGlideModule
import okhttp3.OkHttpClient
import java.io.InputStream
import java.util.concurrent.TimeUnit

/**
 * Configuration réseau de Glide pour toute l'application.
 *
 * Pourquoi ce module existe : par défaut, Glide télécharge les images via
 * `HttpURLConnection` avec des délais fixes de 2,5 s pour la connexion ET
 * pour la lecture. Le proxy de vignettes d'Openverse (catégorie Images de
 * Gip Search) va parfois lui-même chercher et redimensionner l'image côté
 * serveur avant de répondre : sur un réseau mobile ou avec un cache froid,
 * ça dépasse régulièrement 2,5 s. Le résultat concret observé : les
 * vignettes n'apparaissaient jamais, sans le moindre message d'erreur.
 *
 * On remplace donc le chargeur réseau par OkHttp, avec des délais réalistes
 * et une nouvelle tentative automatique en cas de coupure passagère.
 */
@GlideModule
class GipGlideModule : AppGlideModule() {

    override fun registerComponents(context: Context, glide: Glide, registry: Registry) {
        val client = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
        registry.replace(GlideUrl::class.java, InputStream::class.java, OkHttpUrlLoader.Factory(client))
    }

    // Pas besoin d'analyser un AndroidManifest tiers pour trouver d'autres
    // GlideModules : on sait exactement ce qu'on utilise, ça accélère
    // légèrement le tout premier appel à Glide.
    override fun isManifestParsingEnabled(): Boolean = false
}
