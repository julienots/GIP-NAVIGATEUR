package com.gip.browser

import android.content.Context
import android.net.Uri

data class SearchEngine(val id: String, val label: String, val queryUrl: String)

object SearchEngines {

    // "gip" est le moteur par défaut de l'application : il s'appuie sur le
    // point d'entrée HTML de DuckDuckGo (rapide et fiable dans une WebView,
    // sans blocage "navigateur non supporté" comme peut le faire Google).
    val ALL = listOf(
        SearchEngine("gip", "Gip Search", "https://html.duckduckgo.com/html/?q=%s"),
        SearchEngine("duckduckgo", "DuckDuckGo", "https://duckduckgo.com/?q=%s"),
        SearchEngine("google", "Google", "https://www.google.com/search?q=%s"),
        SearchEngine("bing", "Bing", "https://www.bing.com/search?q=%s"),
        SearchEngine("qwant", "Qwant", "https://www.qwant.com/?q=%s"),
        SearchEngine("ecosia", "Ecosia", "https://www.ecosia.org/search?q=%s")
    )

    fun byId(id: String): SearchEngine = ALL.firstOrNull { it.id == id } ?: ALL[0]

    fun buildSearchUrl(context: Context, query: String): String {
        val engine = byId(Prefs.searchEngineId(context))
        return engine.queryUrl.replace("%s", Uri.encode(query))
    }
}
