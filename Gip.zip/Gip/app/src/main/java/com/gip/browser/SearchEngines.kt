package com.gip.browser

import android.content.Context
import android.net.Uri

data class SearchEngine(val id: String, val label: String, val queryUrl: String)

object SearchEngines {

    // "gip" est le moteur par défaut de l'application. Contrairement aux
    // autres, il n'ouvre JAMAIS la page web d'un tiers dans la WebView :
    // MainActivity.performSearch() intercepte cet id et ouvre GipSearchActivity,
    // qui affiche ses propres résultats (voir GipSearchClient pour le détail
    // des sources utilisées en coulisses). Le champ queryUrl ci-dessous n'est
    // donc là que comme filet de sécurité si jamais du code appelait
    // buildSearchUrl() directement pour "gip" par erreur.
    val ALL = listOf(
        SearchEngine("gip", "Gip Search", "https://html.duckduckgo.com/html/?q=%s"),
        SearchEngine("duckduckgo", "DuckDuckGo", "https://duckduckgo.com/?q=%s"),
        SearchEngine("google", "Google", "https://www.google.com/search?q=%s"),
        SearchEngine("bing", "Bing", "https://www.bing.com/search?q=%s"),
        SearchEngine("qwant", "Qwant", "https://www.qwant.com/?q=%s"),
        SearchEngine("ecosia", "Ecosia", "https://www.ecosia.org/search?q=%s")
    )

    fun byId(id: String): SearchEngine = ALL.firstOrNull { it.id == id } ?: ALL[0]

    fun buildSearchUrl(context: Context, query: String): String {
        val engine = byId(Prefs.searchEngineId(context))
        return engine.queryUrl.replace("%s", Uri.encode(query))
    }
}
