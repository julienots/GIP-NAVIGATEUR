package com.gip.browser

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.gip.browser.databinding.ActivityExtensionsBinding

class ExtensionsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityExtensionsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExtensionsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }

        binding.switchAdBlock.isChecked = Prefs.isAdBlockEnabled(this)
        binding.switchAdBlock.setOnCheckedChangeListener { _, checked ->
            Prefs.setAdBlockEnabled(this, checked)
        }

        binding.switchPopupBlock.isChecked = Prefs.isPopupBlockEnabled(this)
        binding.switchPopupBlock.setOnCheckedChangeListener { _, checked ->
            Prefs.setPopupBlockEnabled(this, checked)
        }

        binding.switchDarkReader.isChecked = Prefs.isDarkReaderEnabled(this)
        binding.switchDarkReader.setOnCheckedChangeListener { _, checked ->
            Prefs.setDarkReaderEnabled(this, checked)
        }

        binding.switchImageBlock.isChecked = Prefs.isImageBlockEnabled(this)
        binding.switchImageBlock.setOnCheckedChangeListener { _, checked ->
            Prefs.setImageBlockEnabled(this, checked)
        }

        binding.switchJs.isChecked = Prefs.isJsEnabled(this)
        binding.switchJs.setOnCheckedChangeListener { _, checked ->
            Prefs.setJsEnabled(this, checked)
        }
    }
}
