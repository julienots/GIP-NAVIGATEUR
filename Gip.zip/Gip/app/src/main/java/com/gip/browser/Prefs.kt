package com.gip.browser

import android.content.Context

/**
 * Accès centralisé aux préférences persistantes du navigateur :
 * moteur de recherche, blocage des pubs/popups/images, mode sombre forcé,
 * mode bureau par défaut.
 */
object Prefs {
    private const val NAME = "gip_settings"

    private const val KEY_ENGINE = "search_engine"
    private const val KEY_JS = "js_enabled"
    private const val KEY_ADBLOCK = "adblock_enabled"
    private const val KEY_POPUP_BLOCK = "popup_block_enabled"
    private const val KEY_IMAGE_BLOCK = "image_block_enabled"
    private const val KEY_DARK_READER = "dark_reader_enabled"
    private const val KEY_DESKTOP_DEFAULT = "desktop_default"
    private const val KEY_SAFE_SEARCH = "gip_search_safe"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun searchEngineId(context: Context): String =
        prefs(context).getString(KEY_ENGINE, "gip") ?: "gip"

    fun setSearchEngineId(context: Context, id: String) {
        prefs(context).edit().putString(KEY_ENGINE, id).apply()
    }

    fun isJsEnabled(context: Context) = prefs(context).getBoolean(KEY_JS, true)
    fun setJsEnabled(context: Context, v: Boolean) {
        prefs(context).edit().putBoolean(KEY_JS, v).apply()
    }

    fun isAdBlockEnabled(context: Context) = prefs(context).getBoolean(KEY_ADBLOCK, true)
    fun setAdBlockEnabled(context: Context, v: Boolean) {
        prefs(context).edit().putBoolean(KEY_ADBLOCK, v).apply()
    }

    fun isPopupBlockEnabled(context: Context) = prefs(context).getBoolean(KEY_POPUP_BLOCK, true)
    fun setPopupBlockEnabled(context: Context, v: Boolean) {
        prefs(context).edit().putBoolean(KEY_POPUP_BLOCK, v).apply()
    }

    fun isImageBlockEnabled(context: Context) = prefs(context).getBoolean(KEY_IMAGE_BLOCK, false)
    fun setImageBlockEnabled(context: Context, v: Boolean) {
        prefs(context).edit().putBoolean(KEY_IMAGE_BLOCK, v).apply()
    }

    fun isDarkReaderEnabled(context: Context) = prefs(context).getBoolean(KEY_DARK_READER, false)
    fun setDarkReaderEnabled(context: Context, v: Boolean) {
        prefs(context).edit().putBoolean(KEY_DARK_READER, v).apply()
    }

    fun isDesktopDefault(context: Context) = prefs(context).getBoolean(KEY_DESKTOP_DEFAULT, false)
    fun setDesktopDefault(context: Context, v: Boolean) {
        prefs(context).edit().putBoolean(KEY_DESKTOP_DEFAULT, v).apply()
    }

    /** Recherche sécurisée propre à Gip Search (filtre les résultats explicites). */
    fun isSafeSearchEnabled(context: Context) = prefs(context).getBoolean(KEY_SAFE_SEARCH, true)
    fun setSafeSearchEnabled(context: Context, v: Boolean) {
        prefs(context).edit().putBoolean(KEY_SAFE_SEARCH, v).apply()
    }
}
