package com.gip.browser

import android.content.Context

/**
 * Accès centralisé aux préférences persistantes du navigateur :
 * moteur de recherche, blocage des pubs/popups/images, mode sombre forcé,
 * mode bureau par défaut.
 */
object Prefs {
    private const val NAME = "gip_settings"

    private const val KEY_ENGINE = "search_engine"
    private const val KEY_JS = "js_enabled"
    private const val KEY_ADBLOCK = "adblock_enabled"
    private const val KEY_POPUP_BLOCK = "popup_block_enabled"
    private const val KEY_IMAGE_BLOCK = "image_block_enabled"
    private const val KEY_DARK_READER = "dark_reader_enabled"
    private const val KEY_DESKTOP_DEFAULT = "desktop_default"
    private const val KEY_SAFE_SEARCH = "gip_search_safe"
    private const val KEY_TABS_STATE = "tabs_state_json"
    private const val KEY_ACTIVE_TAB_INDEX = "tabs_active_index"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun searchEngineId(context: Context): String =
        prefs(context).getString(KEY_ENGINE, "gip") ?: "gip"

    fun setSearchEngineId(context: Context, id: String) {
        prefs(context).edit().putString(KEY_ENGINE, id).apply()
    }

    fun isJsEnabled(context: Context) = prefs(context).getBoolean(KEY_JS, true)
    fun setJsEnabled(context: Context, v: Boolean) {
        prefs(context).edit().putBoolean(KEY_JS, v).apply()
    }

    fun isAdBlockEnabled(context: Context) = prefs(context).getBoolean(KEY_ADBLOCK, true)
    fun setAdBlockEnabled(context: Context, v: Boolean) {
        prefs(context).edit().putBoolean(KEY_ADBLOCK, v).apply()
    }

    fun isPopupBlockEnabled(context: Context) = prefs(context).getBoolean(KEY_POPUP_BLOCK, true)
    fun setPopupBlockEnabled(context: Context, v: Boolean) {
        prefs(context).edit().putBoolean(KEY_POPUP_BLOCK, v).apply()
    }

    fun isImageBlockEnabled(context: Context) = prefs(context).getBoolean(KEY_IMAGE_BLOCK, false)
    fun setImageBlockEnabled(context: Context, v: Boolean) {
        prefs(context).edit().putBoolean(KEY_IMAGE_BLOCK, v).apply()
    }

    fun isDarkReaderEnabled(context: Context) = prefs(context).getBoolean(KEY_DARK_READER, false)
    fun setDarkReaderEnabled(context: Context, v: Boolean) {
        prefs(context).edit().putBoolean(KEY_DARK_READER, v).apply()
    }

    fun isDesktopDefault(context: Context) = prefs(context).getBoolean(KEY_DESKTOP_DEFAULT, false)
    fun setDesktopDefault(context: Context, v: Boolean) {
        prefs(context).edit().putBoolean(KEY_DESKTOP_DEFAULT, v).apply()
    }

    /** Recherche sécurisée propre à Gip Search (filtre les résultats explicites). */
    fun isSafeSearchEnabled(context: Context) = prefs(context).getBoolean(KEY_SAFE_SEARCH, true)
    fun setSafeSearchEnabled(context: Context, v: Boolean) {
        prefs(context).edit().putBoolean(KEY_SAFE_SEARCH, v).apply()
    }

    // -----------------------------------------------------------------
    // Apparence : couleur d'accent + taille du texte des pages web
    // -----------------------------------------------------------------

    private const val KEY_ACCENT_THEME = "accent_theme"
    private const val KEY_TEXT_ZOOM = "text_zoom"

    /** Identifiants valides : teal (défaut), blue, purple, pink, red, orange, green. */
    fun accentThemeId(context: Context): String =
        prefs(context).getString(KEY_ACCENT_THEME, "teal") ?: "teal"

    fun setAccentThemeId(context: Context, id: String) {
        prefs(context).edit().putString(KEY_ACCENT_THEME, id).apply()
    }

    /** Résout l'identifiant choisi vers le style de thème correspondant. */
    fun accentThemeStyleRes(context: Context): Int = when (accentThemeId(context)) {
        "blue" -> R.style.Theme_Gip_Blue
        "purple" -> R.style.Theme_Gip_Purple
        "pink" -> R.style.Theme_Gip_Pink
        "red" -> R.style.Theme_Gip_Red
        "orange" -> R.style.Theme_Gip_Orange
        "green" -> R.style.Theme_Gip_Green
        else -> R.style.Theme_Gip_Teal
    }

    /** Zoom du texte des pages web, en pourcentage (WebSettings.textZoom). */
    fun textZoom(context: Context): Int = prefs(context).getInt(KEY_TEXT_ZOOM, 100)
    fun setTextZoom(context: Context, percent: Int) {
        prefs(context).edit().putInt(KEY_TEXT_ZOOM, percent).apply()
    }

    /**
     * Sauvegarde des onglets ouverts (hors onglets privés, jamais persistés)
     * pour les retrouver à la réouverture de l'appli.
     */
    fun saveTabsState(context: Context, json: String, activeIndex: Int) {
        prefs(context).edit()
            .putString(KEY_TABS_STATE, json)
            .putInt(KEY_ACTIVE_TAB_INDEX, activeIndex)
            .apply()
    }

    fun loadTabsState(context: Context): String? = prefs(context).getString(KEY_TABS_STATE, null)

    fun loadActiveTabIndex(context: Context): Int = prefs(context).getInt(KEY_ACTIVE_TAB_INDEX, 0)

    fun clearTabsState(context: Context) {
        prefs(context).edit().remove(KEY_TABS_STATE).remove(KEY_ACTIVE_TAB_INDEX).apply()
    }
}
