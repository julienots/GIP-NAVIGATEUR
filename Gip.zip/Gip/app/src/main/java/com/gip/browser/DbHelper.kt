package com.gip.browser

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class HistoryEntry(val id: Long, val url: String, val title: String, val timestamp: Long)
data class BookmarkEntry(val id: Long, val url: String, val title: String, val timestamp: Long)

class DbHelper(context: Context) : SQLiteOpenHelper(context.applicationContext, "gip.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE history (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "url TEXT, title TEXT, timestamp INTEGER)"
        )
        db.execSQL(
            "CREATE TABLE bookmarks (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "url TEXT UNIQUE, title TEXT, timestamp INTEGER)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS history")
        db.execSQL("DROP TABLE IF EXISTS bookmarks")
        onCreate(db)
    }

    fun addHistory(url: String, title: String) {
        if (url.isBlank() || url.startsWith("file:///android_asset") || url == "about:blank") return
        // Évite de remplir l'historique de doublons lorsqu'une page se recharge
        // plusieurs fois de suite. On conserve toutefois une nouvelle visite
        // après quelques minutes.
        val cutoff = System.currentTimeMillis() - 2 * 60 * 1000L
        val cursor = readableDatabase.rawQuery(
            "SELECT id FROM history WHERE url = ? AND timestamp > ? LIMIT 1",
            arrayOf(url, cutoff.toString())
        )
        val alreadyRecent = cursor.use { it.moveToFirst() }
        if (alreadyRecent) return

        val values = ContentValues().apply {
            put("url", url)
            put("title", title)
            put("timestamp", System.currentTimeMillis())
        }
        writableDatabase.insert("history", null, values)
    }

    fun getHistory(query: String? = null): List<HistoryEntry> {
        val list = mutableListOf<HistoryEntry>()
        val db = readableDatabase
        val cursor = if (query.isNullOrBlank()) {
            db.rawQuery(
                "SELECT id, url, title, timestamp FROM history ORDER BY timestamp DESC LIMIT 1000",
                null
            )
        } else {
            db.rawQuery(
                "SELECT id, url, title, timestamp FROM history " +
                    "WHERE url LIKE ? OR title LIKE ? ORDER BY timestamp DESC LIMIT 1000",
                arrayOf("%$query%", "%$query%")
            )
        }
        cursor.use {
            while (it.moveToNext()) {
                list.add(HistoryEntry(it.getLong(0), it.getString(1), it.getString(2) ?: "", it.getLong(3)))
            }
        }
        return list
    }

    fun deleteHistoryEntry(id: Long) {
        writableDatabase.delete("history", "id = ?", arrayOf(id.toString()))
    }

    fun clearHistory() {
        writableDatabase.delete("history", null, null)
    }

    fun addBookmark(url: String, title: String) {
        val values = ContentValues().apply {
            put("url", url)
            put("title", title)
            put("timestamp", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict(
            "bookmarks", null, values, SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun removeBookmark(url: String) {
        writableDatabase.delete("bookmarks", "url = ?", arrayOf(url))
    }

    fun isBookmarked(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val cursor = readableDatabase.rawQuery("SELECT id FROM bookmarks WHERE url = ?", arrayOf(url))
        val found = cursor.moveToFirst()
        cursor.close()
        return found
    }

    fun getBookmarks(): List<BookmarkEntry> {
        val list = mutableListOf<BookmarkEntry>()
        val cursor = readableDatabase.rawQuery(
            "SELECT id, url, title, timestamp FROM bookmarks ORDER BY timestamp DESC", null
        )
        cursor.use {
            while (it.moveToNext()) {
                list.add(BookmarkEntry(it.getLong(0), it.getString(1), it.getString(2) ?: "", it.getLong(3)))
            }
        }
        return list
    }

    fun deleteBookmark(id: Long) {
        writableDatabase.delete("bookmarks", "id = ?", arrayOf(id.toString()))
    }
}
