package com.gip.browser

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class HistoryEntry(val id: Long, val url: String, val title: String, val timestamp: Long)
data class BookmarkEntry(val id: Long, val url: String, val title: String, val timestamp: Long)

class DbHelper(context: Context) : SQLiteOpenHelper(context.applicationContext, "gip.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE history (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "url TEXT, title TEXT, timestamp INTEGER)"
        )
        db.execSQL(
            "CREATE TABLE bookmarks (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "url TEXT UNIQUE, title TEXT, timestamp INTEGER)"
        )
        db.execSQL(
            "CREATE TABLE search_history (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "query TEXT, timestamp INTEGER)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS search_history (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "query TEXT, timestamp INTEGER)"
            )
        }
    }

    // ---------------------------------------------------------------
    // Historique des recherches Gip Search (suggestions + relance rapide)
    // ---------------------------------------------------------------

    fun addSearchQuery(query: String) {
        val trimmed = query.trim()
        if (trimmed.isBlank()) return
        writableDatabase.delete("search_history", "query = ?", arrayOf(trimmed))
        val values = ContentValues().apply {
            put("query", trimmed)
            put("timestamp", System.currentTimeMillis())
        }
        writableDatabase.insert("search_history", null, values)
        // Ne garde que les 200 recherches les plus récentes.
        writableDatabase.execSQL(
            "DELETE FROM search_history WHERE id NOT IN " +
                "(SELECT id FROM search_history ORDER BY timestamp DESC LIMIT 200)"
        )
    }

    fun getRecentSearches(prefix: String? = null, limit: Int = 6): List<String> {
        val list = mutableListOf<String>()
        val cursor = if (prefix.isNullOrBlank()) {
            readableDatabase.rawQuery(
                "SELECT query FROM search_history ORDER BY timestamp DESC LIMIT ?",
                arrayOf(limit.toString())
            )
        } else {
            readableDatabase.rawQuery(
                "SELECT query FROM search_history WHERE query LIKE ? ORDER BY timestamp DESC LIMIT ?",
                arrayOf("$prefix%", limit.toString())
            )
        }
        cursor.use {
            while (it.moveToNext()) list.add(it.getString(0))
        }
        return list
    }

    fun clearSearchHistory() {
        writableDatabase.delete("search_history", null, null)
    }

    fun addHistory(url: String, title: String) {
        if (url.isBlank() || url.startsWith("file:///android_asset") || url == "about:blank") return
        val values = ContentValues().apply {
            put("url", url)
            put("title", title)
            put("timestamp", System.currentTimeMillis())
        }
        writableDatabase.insert("history", null, values)
    }

    fun getHistory(query: String? = null): List<HistoryEntry> {
        val list = mutableListOf<HistoryEntry>()
        val db = readableDatabase
        val cursor = if (query.isNullOrBlank()) {
            db.rawQuery(
                "SELECT id, url, title, timestamp FROM history ORDER BY timestamp DESC LIMIT 1000",
                null
            )
        } else {
            db.rawQuery(
                "SELECT id, url, title, timestamp FROM history " +
                    "WHERE url LIKE ? OR title LIKE ? ORDER BY timestamp DESC LIMIT 1000",
                arrayOf("%$query%", "%$query%")
            )
        }
        cursor.use {
            while (it.moveToNext()) {
                list.add(HistoryEntry(it.getLong(0), it.getString(1), it.getString(2) ?: "", it.getLong(3)))
            }
        }
        return list
    }

    fun deleteHistoryEntry(id: Long) {
        writableDatabase.delete("history", "id = ?", arrayOf(id.toString()))
    }

    fun clearHistory() {
        writableDatabase.delete("history", null, null)
    }

    fun addBookmark(url: String, title: String) {
        val values = ContentValues().apply {
            put("url", url)
            put("title", title)
            put("timestamp", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict(
            "bookmarks", null, values, SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun removeBookmark(url: String) {
        writableDatabase.delete("bookmarks", "url = ?", arrayOf(url))
    }

    fun isBookmarked(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val cursor = readableDatabase.rawQuery("SELECT id FROM bookmarks WHERE url = ?", arrayOf(url))
        val found = cursor.moveToFirst()
        cursor.close()
        return found
    }

    fun getBookmarks(): List<BookmarkEntry> {
        val list = mutableListOf<BookmarkEntry>()
        val cursor = readableDatabase.rawQuery(
            "SELECT id, url, title, timestamp FROM bookmarks ORDER BY timestamp DESC", null
        )
        cursor.use {
            while (it.moveToNext()) {
                list.add(BookmarkEntry(it.getLong(0), it.getString(1), it.getString(2) ?: "", it.getLong(3)))
            }
        }
        return list
    }

    fun deleteBookmark(id: Long) {
        writableDatabase.delete("bookmarks", "id = ?", arrayOf(id.toString()))
    }
}
