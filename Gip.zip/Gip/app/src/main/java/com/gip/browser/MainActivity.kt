package com.gip.browser

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.speech.RecognizerIntent
import android.view.ContextMenu
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.gip.browser.databinding.ActivityMainBinding
import com.gip.browser.databinding.ItemTabChipBinding
import org.json.JSONArray
import org.json.JSONObject

class Tab(
    val webView: WebView,
    var title: String = "Nouvel onglet",
    val isIncognito: Boolean = false,
    var isDesktopMode: Boolean = false
) {
    // Bouclier Gip : compteur de pubs/traceurs bloqués sur la page actuelle de cet onglet.
    var blockedCount: Int = 0
    val blockedDomains: MutableSet<String> = mutableSetOf()
}

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var db: DbHelper

    private val homeUrl = "file:///android_asset/home.html"
    private val desktopUserAgent =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/125.0.0.0 Safari/537.36"

    private val tabs = mutableListOf<Tab>()
    private var currentTabIndex = -1

    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private var pendingDownloadRequest: DownloadManager.Request? = null
    private var pendingDownloadFileName: String? = null

    private val currentTab: Tab? get() = tabs.getOrNull(currentTabIndex)

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val results: Array<Uri>? = if (result.resultCode == RESULT_OK && data != null) {
            val dataUri = data.data
            if (dataUri != null) arrayOf(dataUri) else null
        } else null
        fileUploadCallback?.onReceiveValue(results)
        fileUploadCallback = null
    }

    private val pageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val url = result.data?.getStringExtra("open_url")
        if (result.resultCode == RESULT_OK && url != null) {
            val newTab = result.data?.getBooleanExtra("open_in_new_tab", false) ?: false
            if (newTab) {
                createNewTab(url)
            } else {
                currentTab?.webView?.loadUrl(url)
            }
        }
    }

    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startPendingDownload()
        else Toast.makeText(this, "Permission refusée, téléchargement annulé", Toast.LENGTH_SHORT).show()
    }

    // Résultat de l'écran "Gip Search" (affichage propre à Gip, voir GipSearchActivity)
    private val gipSearchLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val url = result.data?.getStringExtra("open_url")
        if (result.resultCode == RESULT_OK && url != null) {
            currentTab?.webView?.loadUrl(url)
        }
    }

    // Recherche vocale déclenchée depuis la barre d'adresse ou la page d'accueil
    private val voiceSearchLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                binding.addressBar.setText(spoken)
                performSearch(spoken)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = DbHelper(this)

        setupControls()
        // Enable le vrai débogage à distance Chrome : brancher le téléphone en USB
        // et ouvrir chrome://inspect sur un ordinateur donne les DevTools complets
        // (Éléments, Console, Réseau) sur les pages ouvertes dans Gip — comme sur PC.
        WebView.setWebContentsDebuggingEnabled(true)

        if (!restoreTabsState()) {
            createNewTab(homeUrl)
        }
    }

    override fun onPause() {
        super.onPause()
        persistTabsState()
    }

    override fun onStop() {
        super.onStop()
        persistTabsState()
    }

    /** Sauvegarde les onglets non-privés pour les retrouver à la prochaine ouverture de l'appli. */
    private fun persistTabsState() {
        if (tabs.isEmpty()) return
        val arr = JSONArray()
        var activeIndexInSaved = 0
        var savedIndex = 0
        for ((i, tab) in tabs.withIndex()) {
            if (tab.isIncognito) continue
            val obj = JSONObject()
            obj.put("url", tab.webView.url ?: homeUrl)
            obj.put("title", tab.title)
            obj.put("desktop", tab.isDesktopMode)
            arr.put(obj)
            if (i == currentTabIndex) activeIndexInSaved = savedIndex
            savedIndex++
        }
        if (arr.length() == 0) {
            Prefs.clearTabsState(this)
        } else {
            Prefs.saveTabsState(this, arr.toString(), activeIndexInSaved)
        }
    }

    /** Recrée les onglets sauvegardés. Renvoie false s'il n'y avait rien à restaurer. */
    private fun restoreTabsState(): Boolean {
        val json = Prefs.loadTabsState(this) ?: return false
        return try {
            val arr = JSONArray(json)
            if (arr.length() == 0) return false
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val url = obj.optString("url").takeIf { it.isNotBlank() } ?: homeUrl
                val tab = createNewTab(url)
                val desktop = obj.optBoolean("desktop", false)
                if (desktop) {
                    tab.isDesktopMode = true
                    tab.webView.settings.userAgentString = desktopUserAgent
                    tab.webView.reload()
                }
            }
            val activeIndex = Prefs.loadActiveTabIndex(this).coerceIn(0, tabs.size - 1)
            switchToTab(activeIndex)
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun onResume() {
        super.onResume()
        // Ré-applique les préférences (JS, images) qui peuvent avoir changé
        // dans l'écran Paramètres / Extensions.
        for (tab in tabs) applyContentPrefs(tab.webView)
        updateStarIcon()
    }

    // ---------------------------------------------------------------
    // Gestion des onglets
    // ---------------------------------------------------------------

    private fun createNewTab(url: String? = null, incognito: Boolean = false): Tab {
        val webView = WebView(this)
        val tab = Tab(webView, isIncognito = incognito)
        setupWebViewForTab(tab)
        if (Prefs.isDesktopDefault(this)) {
            tab.isDesktopMode = true
            webView.settings.userAgentString = desktopUserAgent
        }
        tabs.add(tab)
        binding.webViewContainer.addView(
            webView,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        switchToTab(tabs.size - 1)
        webView.loadUrl(url ?: homeUrl)
        Toast.makeText(this, if (incognito) "Onglet privé ouvert" else "Nouvel onglet", Toast.LENGTH_SHORT).show()
        return tab
    }

    private fun switchToTab(index: Int) {
        if (index !in tabs.indices) return
        currentTabIndex = index
        for ((i, tab) in tabs.withIndex()) {
            tab.webView.visibility = if (i == index) View.VISIBLE else View.GONE
        }
        refreshTabStrip()
        updateAddressBarFromCurrentTab()
        updateNavButtons()
        updateStarIcon()
        updateShieldBadge()
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs[index]
        binding.webViewContainer.removeView(tab.webView)
        tab.webView.destroy()
        tabs.removeAt(index)

        if (tabs.isEmpty()) {
            createNewTab(homeUrl)
            return
        }
        val newIndex = if (index <= currentTabIndex) (currentTabIndex - 1).coerceAtLeast(0) else currentTabIndex
        switchToTab(newIndex.coerceIn(0, tabs.size - 1))
    }

    private fun refreshTabStrip() {
        binding.tabsContainer.removeAllViews()
        for ((i, tab) in tabs.withIndex()) {
            val chip = ItemTabChipBinding.inflate(LayoutInflater.from(this), binding.tabsContainer, false)
            val label = if (tab.isIncognito) "🕵 ${tab.title}" else tab.title
            chip.tabTitle.text = label
            chip.root.setBackgroundResource(if (i == currentTabIndex) R.drawable.bg_tab_active else R.drawable.bg_tab_inactive)
            chip.root.setOnClickListener { switchToTab(i) }
            chip.tabClose.setOnClickListener { closeTab(i) }
            binding.tabsContainer.addView(chip.root)
        }
    }

    // ---------------------------------------------------------------
    // Configuration d'une WebView
    // ---------------------------------------------------------------

    private fun setupWebViewForTab(tab: Tab) {
        val webView = tab.webView
        applyContentPrefs(webView)
        webView.settings.loadWithOverviewMode = true
        webView.settings.useWideViewPort = true
        webView.settings.builtInZoomControls = true
        webView.settings.displayZoomControls = false
        webView.settings.setSupportZoom(true)
        webView.settings.setSupportMultipleWindows(true)
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.addJavascriptInterface(GipBridge(tab), "Gip")

        // Fluidité : rendu accéléré matériellement + pré-rendu hors écran,
        // pour un défilement et un zoom plus doux sur les pages lourdes.
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        webView.settings.offscreenPreRaster = true
        webView.settings.cacheMode = WebSettings.LOAD_DEFAULT

        if (tab.isIncognito) {
            webView.settings.cacheMode = WebSettings.LOAD_NO_CACHE
            CookieManager.getInstance().setAcceptCookie(true)
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url?.toString() ?: return super.shouldInterceptRequest(view, request)
                if (Prefs.isAdBlockEnabled(this@MainActivity) && AdBlock.isBlockedUrl(url)) {
                    synchronized(tab) {
                        tab.blockedCount++
                        Uri.parse(url).host?.let { tab.blockedDomains.add(it) }
                    }
                    if (tab === currentTab) this@MainActivity.runOnUiThread { updateShieldBadge() }
                    return AdBlock.blockedResponse()
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                // Bouclier Gip : on repart de zéro à chaque nouvelle page.
                tab.blockedCount = 0
                tab.blockedDomains.clear()
                if (tab === currentTab) updateShieldBadge()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (tab === currentTab) {
                    if (url != null && url != homeUrl) {
                        binding.addressBar.setText(url)
                    } else {
                        binding.addressBar.setText("")
                    }
                    updateStarIcon()
                    updateNavButtons()
                    updateShieldBadge()
                }
                tab.title = view?.title?.takeIf { it.isNotBlank() } ?: (url ?: "Nouvel onglet")
                refreshTabStrip()

                if (!tab.isIncognito && url != null && url != homeUrl) {
                    db.addHistory(url, view?.title ?: url)
                }

                if (Prefs.isDarkReaderEnabled(this@MainActivity)) {
                    injectDarkReader(view)
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                if (tab === currentTab) {
                    binding.progressBar.progress = newProgress
                    binding.progressBar.visibility =
                        if (newProgress in 1..99) View.VISIBLE else View.GONE
                }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                super.onReceivedTitle(view, title)
                if (!title.isNullOrBlank()) {
                    tab.title = title
                    refreshTabStrip()
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback
                return try {
                    val intent = fileChooserParams?.createIntent()
                        ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
                    fileChooserLauncher.launch(intent)
                    true
                } catch (e: Exception) {
                    fileUploadCallback = null
                    false
                }
            }

            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                if (Prefs.isPopupBlockEnabled(this@MainActivity) && !isUserGesture) {
                    Toast.makeText(this@MainActivity, "Popup bloquée", Toast.LENGTH_SHORT).show()
                    return false
                }
                val newTab = createNewTab(null, tab.isIncognito)
                val transport = resultMsg?.obj as? WebView.WebViewTransport
                transport?.webView = newTab.webView
                resultMsg?.sendToTarget()
                return true
            }
        }

        webView.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            startDownload(url, userAgent, contentDisposition, mimeType)
        })

        registerForContextMenu(webView)
    }

    private fun applyContentPrefs(webView: WebView) {
        webView.settings.javaScriptEnabled = Prefs.isJsEnabled(this)
        webView.settings.blockNetworkImage = Prefs.isImageBlockEnabled(this)
        webView.settings.loadsImagesAutomatically = !Prefs.isImageBlockEnabled(this)
    }

    private fun injectDarkReader(view: WebView?) {
        val js = """
            (function() {
                var css = 'html{filter:invert(1) hue-rotate(180deg) !important;} img,video,picture,svg,canvas,iframe{filter:invert(1) hue-rotate(180deg) !important;}';
                var style = document.getElementById('gip-dark-reader-style');
                if (!style) {
                    style = document.createElement('style');
                    style.id = 'gip-dark-reader-style';
                    document.head.appendChild(style);
                }
                style.innerHTML = css;
            })();
        """.trimIndent()
        view?.evaluateJavascript(js, null)
    }

    // ---------------------------------------------------------------
    // Contrôles (barre d'adresse, boutons, menu)
    // ---------------------------------------------------------------

    private fun setupControls() {
        binding.btnBack.setOnClickListener {
            currentTab?.webView?.let { if (it.canGoBack()) it.goBack() }
        }
        binding.btnForward.setOnClickListener {
            currentTab?.webView?.let { if (it.canGoForward()) it.goForward() }
        }
        binding.btnReload.setOnClickListener { currentTab?.webView?.reload() }
        binding.btnHome.setOnClickListener { currentTab?.webView?.loadUrl(homeUrl) }
        binding.btnStar.setOnClickListener { toggleBookmark() }
        binding.btnBookmarks.setOnClickListener {
            pageLauncher.launch(Intent(this, BookmarksActivity::class.java))
        }
        binding.btnShare.setOnClickListener { shareCurrentUrl() }
        binding.btnNewTab.setOnClickListener { createNewTab(homeUrl) }
        binding.btnMenu.setOnClickListener { showOverflowMenu(it) }
        binding.btnMic.setOnClickListener { launchVoiceSearch() }
        binding.btnShield.setOnClickListener { showShieldDialog() }

        binding.addressBar.setOnEditorActionListener { _, actionId, event ->
            val isEnter = event != null &&
                event.keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || isEnter) {
                loadFromAddressBar()
                true
            } else {
                false
            }
        }

        binding.btnFindClose.setOnClickListener { hideFindBar() }
        binding.btnFindUp.setOnClickListener { currentTab?.webView?.findNext(false) }
        binding.btnFindDown.setOnClickListener { currentTab?.webView?.findNext(true) }
        binding.findQuery.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                currentTab?.webView?.findAllAsync(binding.findQuery.text.toString())
                true
            } else {
                false
            }
        }
    }

    private fun showOverflowMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menuInflater.inflate(R.menu.menu_main, popup.menu)
        popup.menu.findItem(R.id.action_desktop_mode)?.isChecked = currentTab?.isDesktopMode == true
        popup.setOnMenuItemClickListener { item -> handleMenuItem(item) }
        popup.show()
    }

    private fun handleMenuItem(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_new_tab -> createNewTab(homeUrl)
            R.id.action_new_incognito -> createNewTab(homeUrl, incognito = true)
            R.id.action_find_in_page -> showFindBar()
            R.id.action_inspector -> openInspector()
            R.id.action_desktop_mode -> toggleDesktopMode()
            R.id.action_history -> pageLauncher.launch(Intent(this, HistoryActivity::class.java))
            R.id.action_bookmarks -> pageLauncher.launch(Intent(this, BookmarksActivity::class.java))
            R.id.action_extensions -> startActivity(Intent(this, ExtensionsActivity::class.java))
            R.id.action_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            else -> return false
        }
        return true
    }

    private fun toggleDesktopMode() {
        val tab = currentTab ?: return
        tab.isDesktopMode = !tab.isDesktopMode
        tab.webView.settings.userAgentString = if (tab.isDesktopMode) desktopUserAgent else null
        tab.webView.reload()
        Toast.makeText(
            this,
            if (tab.isDesktopMode) "Version ordinateur activée" else "Version mobile activée",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun showFindBar() {
        binding.findBar.visibility = View.VISIBLE
        binding.findQuery.requestFocus()
        currentTab?.webView?.setFindListener { activeMatchOrdinal, numberOfMatches, _ ->
            val shown = if (numberOfMatches == 0) 0 else activeMatchOrdinal + 1
            binding.findCount.text = "$shown/$numberOfMatches"
        }
    }

    private fun hideFindBar() {
        binding.findBar.visibility = View.GONE
        binding.findQuery.setText("")
        currentTab?.webView?.clearMatches()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(binding.findQuery.windowToken, 0)
    }

    // ---------------------------------------------------------------
    // Inspecteur HTML (en plus du vrai débogage à distance activé au démarrage)
    // ---------------------------------------------------------------

    private fun openInspector() {
        val webView = currentTab?.webView ?: return
        val url = webView.url
        if (url == null || url == homeUrl) {
            Toast.makeText(this, "Ouvrez d'abord une page à inspecter", Toast.LENGTH_SHORT).show()
            return
        }
        val js = """
            (function() {
                var info = {
                    title: document.title,
                    scripts: document.scripts.length,
                    images: document.images.length,
                    links: document.links.length,
                    forms: document.forms.length,
                    metas: document.querySelectorAll('meta').length,
                    charset: document.characterSet || '',
                    doctype: document.doctype ? document.doctype.name : ''
                };
                return JSON.stringify({ html: document.documentElement.outerHTML, info: info });
            })();
        """.trimIndent()

        webView.evaluateJavascript(js) { raw ->
            try {
                // evaluateJavascript renvoie une chaîne encodée en JSON : on la
                // décode une première fois pour retrouver notre JSON.stringify(...).
                val jsonString = org.json.JSONTokener(raw).nextValue() as String
                val obj = JSONObject(jsonString)
                val html = obj.optString("html")
                val info = obj.optJSONObject("info") ?: JSONObject()

                val file = java.io.File(cacheDir, "gip_inspector_source.html")
                file.writeText(html)

                val intent = Intent(this, InspectorActivity::class.java).apply {
                    putExtra("source_path", file.absolutePath)
                    putExtra("page_url", url)
                    putExtra("page_info", info.toString())
                }
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "Impossible d'inspecter cette page.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadFromAddressBar() {
        val input = binding.addressBar.text.toString().trim()
        if (input.isEmpty()) return
        val looksLikeUrl = input.contains(".") && !input.contains(" ")
        when {
            input.startsWith("http://") || input.startsWith("https://") -> currentTab?.webView?.loadUrl(input)
            looksLikeUrl -> currentTab?.webView?.loadUrl("https://$input")
            else -> performSearch(input)
        }
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(binding.addressBar.windowToken, 0)
    }

    /**
     * Point d'entrée unique pour toute recherche par mots-clés (barre d'adresse,
     * accueil, recherche vocale). Si le moteur choisi est "Gip Search", on ouvre
     * notre propre écran de résultats (GipSearchActivity) plutôt que de charger
     * une page web d'un moteur tiers dans la WebView.
     */
    private fun performSearch(query: String) {
        if (query.isBlank()) return
        if (Prefs.searchEngineId(this) == "gip") {
            val intent = Intent(this, GipSearchActivity::class.java).putExtra("query", query)
            gipSearchLauncher.launch(intent)
        } else {
            currentTab?.webView?.loadUrl(SearchEngines.buildSearchUrl(this, query))
        }
    }

    private fun launchVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Parlez pour rechercher avec Gip")
        }
        try {
            voiceSearchLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Reconnaissance vocale indisponible sur cet appareil", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------
    // Bouclier Gip (compteur de pubs/traceurs bloqués par onglet)
    // ---------------------------------------------------------------

    private fun updateShieldBadge() {
        val count = currentTab?.blockedCount ?: 0
        binding.shieldBadge.text = if (count > 99) "99+" else count.toString()
        binding.shieldBadge.visibility = if (count > 0) View.VISIBLE else View.GONE
    }

    private fun showShieldDialog() {
        val tab = currentTab ?: return
        val message = if (tab.blockedDomains.isEmpty()) {
            "Aucun traceur ni publicité détecté sur cette page pour l'instant."
        } else {
            "Bloqué sur cette page :\n\n" + tab.blockedDomains.sorted().joinToString("\n") { "• $it" }
        }
        AlertDialog.Builder(this)
            .setTitle("Bouclier Gip — ${tab.blockedCount} élément(s) bloqué(s)")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    // ---------------------------------------------------------------
    // Pont JavaScript exposé à la page d'accueil (file:///android_asset/home.html)
    // ---------------------------------------------------------------

    /**
     * N'agit que si l'onglet affiche encore réellement la page d'accueil de
     * Gip : cela évite qu'un site web externe, une fois chargé dans le même
     * onglet, puisse continuer à appeler ce pont (et par exemple lire
     * l'historique via getShortcuts()).
     */
    inner class GipBridge(private val tab: Tab) {
        private fun isHome() = tab.webView.url == homeUrl

        @JavascriptInterface
        fun search(query: String) {
            if (!isHome()) return
            runOnUiThread { performSearch(query) }
        }

        @JavascriptInterface
        fun startVoiceSearch() {
            if (!isHome()) return
            runOnUiThread { launchVoiceSearch() }
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            if (!isHome()) return
            runOnUiThread { tab.webView.loadUrl(url) }
        }

        /** Renvoie les sites les plus visités récemment, pour la grille de raccourcis de l'accueil. */
        @JavascriptInterface
        fun getShortcuts(): String {
            if (!isHome()) return "[]"
            val entries = db.getHistory(null).take(300)
            val byHost = entries.groupBy { hostOf(it.url) }.filterKeys { it != null }
            val top = byHost.entries.sortedByDescending { it.value.size }.take(8)
            val arr = JSONArray()
            for ((host, list) in top) {
                val obj = JSONObject()
                obj.put("host", host)
                obj.put("url", list.first().url)
                obj.put("title", list.first().title.ifBlank { host ?: "" })
                arr.put(obj)
            }
            return arr.toString()
        }
    }

    private fun hostOf(url: String): String? = try {
        Uri.parse(url).host?.removePrefix("www.")
    } catch (e: Exception) {
        null
    }

    private fun updateAddressBarFromCurrentTab() {
        val url = currentTab?.webView?.url
        binding.addressBar.setText(if (url != null && url != homeUrl) url else "")
    }

    private fun updateNavButtons() {
        val webView = currentTab?.webView
        binding.btnBack.alpha = if (webView?.canGoBack() == true) 1f else 0.35f
        binding.btnForward.alpha = if (webView?.canGoForward() == true) 1f else 0.35f
    }

    // ---------------------------------------------------------------
    // Favoris
    // ---------------------------------------------------------------

    private fun toggleBookmark() {
        val webView = currentTab?.webView ?: return
        val url = webView.url ?: return
        if (url == homeUrl) return
        if (db.isBookmarked(url)) {
            db.removeBookmark(url)
        } else {
            db.addBookmark(url, webView.title ?: url)
        }
        updateStarIcon()
    }

    private fun updateStarIcon() {
        val url = currentTab?.webView?.url
        val filled = db.isBookmarked(url)
        binding.btnStar.setImageResource(
            if (filled) R.drawable.ic_star_filled else R.drawable.ic_star_outline
        )
    }

    private fun shareCurrentUrl() {
        val url = currentTab?.webView?.url ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, url)
        }
        startActivity(Intent.createChooser(intent, "Partager via"))
    }

    // ---------------------------------------------------------------
    // Menu contextuel (appui long sur un lien)
    // ---------------------------------------------------------------

    override fun onCreateContextMenu(menu: ContextMenu, v: View, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        val webView = v as? WebView ?: return
        val result = webView.hitTestResult
        val url = result.extra ?: return
        if (result.type == WebView.HitTestResult.SRC_ANCHOR_TYPE ||
            result.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
        ) {
            menu.setHeaderTitle(url)
            menu.add(0, 1, 0, "Ouvrir dans un nouvel onglet").setOnMenuItemClickListener {
                createNewTab(url, currentTab?.isIncognito ?: false)
                true
            }
            menu.add(0, 2, 0, "Copier le lien").setOnMenuItemClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("url", url))
                Toast.makeText(this, "Lien copié", Toast.LENGTH_SHORT).show()
                true
            }
            menu.add(0, 3, 0, "Partager le lien").setOnMenuItemClickListener {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, url)
                }
                startActivity(Intent.createChooser(intent, "Partager via"))
                true
            }
        }
    }

    // ---------------------------------------------------------------
    // Téléchargements
    // ---------------------------------------------------------------

    private fun startDownload(url: String, userAgent: String, contentDisposition: String, mimeType: String) {
        val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
        val request = DownloadManager.Request(Uri.parse(url)).apply {
            setMimeType(mimeType)
            val cookies = CookieManager.getInstance().getCookie(url)
            addRequestHeader("cookie", cookies)
            addRequestHeader("User-Agent", userAgent)
            setDescription("Téléchargement en cours…")
            setTitle(fileName)
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDownloadRequest = request
            pendingDownloadFileName = fileName
            storagePermissionLauncher.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }

        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        dm.enqueue(request)
        Toast.makeText(this, "Téléchargement démarré : $fileName", Toast.LENGTH_LONG).show()
    }

    private fun startPendingDownload() {
        val request = pendingDownloadRequest ?: return
        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        dm.enqueue(request)
        Toast.makeText(this, "Téléchargement démarré : $pendingDownloadFileName", Toast.LENGTH_LONG).show()
        pendingDownloadRequest = null
        pendingDownloadFileName = null
    }

    // ---------------------------------------------------------------
    // Bouton retour matériel
    // ---------------------------------------------------------------

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val webView = currentTab?.webView
        when {
            binding.findBar.visibility == View.VISIBLE -> hideFindBar()
            webView != null && webView.canGoBack() -> webView.goBack()
            tabs.size > 1 -> closeTab(currentTabIndex)
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        for (tab in tabs) tab.webView.destroy()
        super.onDestroy()
    }
}
