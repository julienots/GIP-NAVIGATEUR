package com.gip.browser

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.gip.browser.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val homeUrl = "file:///android_asset/home.html"
    private val prefsName = "gip_prefs"
    private val bookmarksKey = "bookmarks"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupWebView()
        setupControls()

        binding.webView.loadUrl(homeUrl)
    }

    private fun setupWebView() {
        val webView = binding.webView
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadWithOverviewMode = true
        webView.settings.useWideViewPort = true
        webView.settings.builtInZoomControls = true
        webView.settings.displayZoomControls = false
        webView.settings.setSupportZoom(true)

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (url != null && url != homeUrl) {
                    binding.addressBar.setText(url)
                } else {
                    binding.addressBar.setText("")
                }
                updateStarIcon()
                updateNavButtons()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                binding.progressBar.progress = newProgress
                binding.progressBar.visibility =
                    if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }
    }

    private fun setupControls() {
        binding.btnBack.setOnClickListener {
            if (binding.webView.canGoBack()) binding.webView.goBack()
        }
        binding.btnForward.setOnClickListener {
            if (binding.webView.canGoForward()) binding.webView.goForward()
        }
        binding.btnReload.setOnClickListener {
            binding.webView.reload()
        }
        binding.btnHome.setOnClickListener {
            binding.webView.loadUrl(homeUrl)
        }
        binding.btnStar.setOnClickListener {
            toggleBookmark()
        }
        binding.btnBookmarks.setOnClickListener {
            showBookmarks()
        }
        binding.btnShare.setOnClickListener {
            shareCurrentUrl()
        }

        binding.addressBar.setOnEditorActionListener { _, actionId, event ->
            val isEnter = event != null &&
                event.keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || isEnter) {
                loadFromAddressBar()
                true
            } else {
                false
            }
        }
    }

    private fun loadFromAddressBar() {
        val input = binding.addressBar.text.toString().trim()
        if (input.isEmpty()) return
        binding.webView.loadUrl(normalizeInput(input))
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(binding.addressBar.windowToken, 0)
    }

    private fun normalizeInput(input: String): String {
        val looksLikeUrl = input.contains(".") && !input.contains(" ")
        return when {
            input.startsWith("http://") || input.startsWith("https://") -> input
            looksLikeUrl -> "https://$input"
            else -> "https://www.google.com/search?q=${Uri.encode(input)}"
        }
    }

    private fun updateNavButtons() {
        binding.btnBack.alpha = if (binding.webView.canGoBack()) 1f else 0.35f
        binding.btnForward.alpha = if (binding.webView.canGoForward()) 1f else 0.35f
    }

    private fun getBookmarks(): MutableSet<String> {
        val prefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        return prefs.getStringSet(bookmarksKey, mutableSetOf())!!.toMutableSet()
    }

    private fun saveBookmarks(set: MutableSet<String>) {
        val prefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        prefs.edit().putStringSet(bookmarksKey, set).apply()
    }

    private fun toggleBookmark() {
        val url = binding.webView.url ?: return
        if (url == homeUrl) return
        val bookmarks = getBookmarks()
        if (bookmarks.contains(url)) {
            bookmarks.remove(url)
        } else {
            bookmarks.add(url)
        }
        saveBookmarks(bookmarks)
        updateStarIcon()
    }

    private fun updateStarIcon() {
        val url = binding.webView.url
        val filled = url != null && getBookmarks().contains(url)
        binding.btnStar.setImageResource(
            if (filled) R.drawable.ic_star_filled else R.drawable.ic_star_outline
        )
    }

    private fun showBookmarks() {
        val bookmarks = getBookmarks().toList()
        if (bookmarks.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("Favoris")
                .setMessage("Aucun favori pour le moment.")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Favoris")
            .setItems(bookmarks.toTypedArray()) { _, which ->
                binding.webView.loadUrl(bookmarks[which])
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun shareCurrentUrl() {
        val url = binding.webView.url ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, url)
        }
        startActivity(Intent.createChooser(intent, "Partager via"))
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (binding.webView.canGoBack()) {
            binding.webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
