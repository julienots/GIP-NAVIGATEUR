package com.gip.browser

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.gip.browser.databinding.ActivityHistoryBinding
import com.gip.browser.databinding.ItemLinkRowBinding
import java.text.DateFormat

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: HistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = DbHelper(this)

        adapter = HistoryAdapter(this, mutableListOf())
        binding.listView.adapter = adapter

        binding.btnBack.setOnClickListener { finish() }
        binding.btnClearAll.setOnClickListener { confirmClearAll() }

        binding.listView.setOnItemClickListener { _, _, position, _ ->
            val entry = adapter.getItem(position) ?: return@setOnItemClickListener
            val intent = Intent().putExtra("open_url", entry.url)
            setResult(RESULT_OK, intent)
            finish()
        }

        binding.listView.setOnItemLongClickListener { _, _, position, _ ->
            val entry = adapter.getItem(position) ?: return@setOnItemLongClickListener true
            AlertDialog.Builder(this)
                .setTitle("Supprimer cette entrée ?")
                .setMessage(entry.url)
                .setPositiveButton("Supprimer") { _, _ ->
                    db.deleteHistoryEntry(entry.id)
                    loadHistory(binding.searchQuery.text.toString())
                }
                .setNegativeButton("Annuler", null)
                .show()
            true
        }

        binding.searchQuery.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                loadHistory(s.toString())
            }
        })

        loadHistory(null)
    }

    override fun onResume() {
        super.onResume()
        loadHistory(binding.searchQuery.text.toString())
    }

    private fun loadHistory(query: String?) {
        val entries = db.getHistory(query)
        adapter.replaceAll(entries)
        binding.emptyText.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun confirmClearAll() {
        AlertDialog.Builder(this)
            .setTitle("Tout effacer")
            .setMessage("Supprimer tout l'historique de navigation ?")
            .setPositiveButton("Effacer") { _, _ ->
                db.clearHistory()
                loadHistory(null)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }
}

class HistoryAdapter(
    context: AppCompatActivity,
    private var items: MutableList<HistoryEntry>
) : ArrayAdapter<HistoryEntry>(context, 0, items) {

    private val dateFormat = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)

    fun replaceAll(newItems: List<HistoryEntry>) {
        items = newItems.toMutableList()
        clear()
        addAll(items)
        notifyDataSetChanged()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val binding = if (convertView == null) {
            ItemLinkRowBinding.inflate(LayoutInflater.from(context), parent, false)
        } else {
            ItemLinkRowBinding.bind(convertView)
        }
        val entry = getItem(position)
        if (entry != null) {
            binding.rowTitle.text = entry.title.ifBlank { entry.url }
            binding.rowUrl.text = "${entry.url}  ·  ${dateFormat.format(entry.timestamp)}"
        }
        return binding.root
    }
}
