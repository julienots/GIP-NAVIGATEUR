package com.gip.browser

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

/**
 * Bloqueur de publicités / traceurs.
 *
 * Deux couches, comme un vrai bloqueur type uBlock Origin :
 *  1) Blocage réseau : les requêtes vers des domaines connus de pub/tracking
 *     sont interceptées et remplacées par une réponse vide (voir MainActivity,
 *     shouldInterceptRequest). C'est ce qui économise de la donnée et empêche
 *     les scripts de traqueurs de s'exécuter.
 *  2) Blocage cosmétique : même quand une pub est servie par le site lui-même
 *     (donc pas bloquable au niveau réseau), on masque en CSS les blocs connus
 *     pour être des emplacements publicitaires, pour éviter les espaces vides
 *     et le contenu "pub" restant visible (voir injectCosmeticRules).
 */
object AdBlock {

    val BLOCKED_DOMAINS = setOf(
        // Régies publicitaires / display
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "google-analytics.com", "googletagmanager.com", "googletagservices.com",
        "adservice.google.com", "adservice.google.fr", "adnxs.com", "adsafeprotected.com",
        "moatads.com", "scorecardresearch.com", "taboola.com", "outbrain.com",
        "criteo.com", "criteo.net", "pubmatic.com", "rubiconproject.com",
        "casalemedia.com", "openx.net", "smartadserver.com", "adform.net",
        "advertising.com", "amazon-adsystem.com", "yieldmo.com", "media.net",
        "bidswitch.net", "mathtag.com", "quantserve.com", "chartbeat.com",
        "3lift.com", "indexexchange.com", "sharethrough.com", "sovrn.com",
        "gumgum.com", "yieldlab.net", "adition.com", "smartclip.net",
        "teads.tv", "adsrvr.org", "turn.com", "rlcdn.com", "bluekai.com",
        "krxd.net", "demdex.net", "everesttech.net", "serving-sys.com",
        "atdmt.com", "flashtalking.com", "adtechus.com", "revcontent.com",
        "mgid.com", "zergnet.com", "content-ad.net", "adblade.com",
        // Analytics / traçage comportemental
        "hotjar.com", "mixpanel.com", "connect.facebook.net", "facebook.net",
        "analytics.tiktok.com", "app-measurement.com", "adjust.com",
        "appsflyer.com", "branch.io", "onesignal.com", "segment.io",
        "segment.com", "amplitude.com", "fullstory.com", "clarity.ms",
        "newrelic.com", "nr-data.net", "sentry.io", "crazyegg.com",
        "optimizely.com", "cxense.com", "chartboost.com", "adcolony.com",
        // Publicité mobile / SDK in-app
        "unityads.unity3d.com", "applovin.com", "vungle.com", "inmobi.com",
        "startapp.com", "mopub.com", "ironsrc.com", "smaato.com", "flurry.com",
        "exoclick.com", "propellerads.com", "popads.net", "adroll.com",
        "bing-shopping.microsoft.com", "clickadu.com", "adcash.com",
        "juicyads.com", "trafficjunky.net", "popcash.net"
    )

    /**
     * Sélecteurs CSS génériques correspondant à des blocs publicitaires
     * courants (identifiants/classes très répandus dans l'industrie). Le
     * risque de faux positif est faible car ces motifs ciblent presque
     * exclusivement des conteneurs de pub, pas du contenu éditorial.
     */
    private val COSMETIC_SELECTORS = listOf(
        "[id*='google_ads']", "[id^='div-gpt-ad']", "[id*='dfp-ad']",
        "[class*='adsbygoogle']", "ins.adsbygoogle",
        "[class^='ad-container']", "[class*=' ad-container']",
        "[class^='ad-banner']", "[class*=' ad-banner']",
        "[class^='ad-slot']", "[class*=' ad-slot']",
        "[class*='sponsored-content']", "[class*='advertisement']",
        "[id*='taboola']", "[id*='outbrain']", "[class*='taboola']",
        "[class*='outbrain']", "[class*='sticky-ad']", "[class*='banner-ad']",
        "[data-ad-slot]", "[data-google-query-id]", "iframe[src*='doubleclick']",
        "iframe[src*='googlesyndication']"
    )

    private val emptyResponse: WebResourceResponse
        get() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    fun isBlockedUrl(url: String): Boolean {
        val host = try {
            Uri.parse(url).host?.lowercase()
        } catch (e: Exception) {
            null
        } ?: return false
        return BLOCKED_DOMAINS.any { host == it || host.endsWith(".$it") }
    }

    fun blockedResponse(): WebResourceResponse = emptyResponse

    /** JS à injecter pour masquer les emplacements publicitaires restants côté client. */
    fun cosmeticRulesJs(): String {
        val css = COSMETIC_SELECTORS.joinToString(",") { it }
            .replace("'", "\\'")
        return """
            (function() {
                var css = '$css { display: none !important; visibility: hidden !important; height: 0 !important; }';
                var style = document.getElementById('gip-adblock-cosmetic');
                if (!style) {
                    style = document.createElement('style');
                    style.id = 'gip-adblock-cosmetic';
                    document.documentElement.appendChild(style);
                }
                style.textContent = css;
            })();
        """.trimIndent()
    }
}
