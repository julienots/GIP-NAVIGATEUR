package com.gip.browser

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

/**
 * Bloqueur de publicités / traceurs très simple, basé sur une liste de
 * domaines connus. Ce n'est pas une vraie extension type "uBlock Origin"
 * (Android WebView ne permet pas d'exécuter des extensions Chrome), mais
 * ça filtre déjà l'essentiel des régies publicitaires et traceurs.
 */
object AdBlock {

    val BLOCKED_DOMAINS = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "google-analytics.com", "googletagmanager.com", "googletagservices.com",
        "adservice.google.com", "adnxs.com", "adsafeprotected.com",
        "moatads.com", "scorecardresearch.com", "taboola.com", "outbrain.com",
        "criteo.com", "criteo.net", "pubmatic.com", "rubiconproject.com",
        "casalemedia.com", "openx.net", "smartadserver.com", "adform.net",
        "advertising.com", "amazon-adsystem.com", "yieldmo.com", "media.net",
        "bidswitch.net", "mathtag.com", "quantserve.com", "chartbeat.com",
        "hotjar.com", "mixpanel.com", "connect.facebook.net", "facebook.net",
        "analytics.tiktok.com", "app-measurement.com", "adjust.com",
        "appsflyer.com", "branch.io", "onesignal.com", "unityads.unity3d.com",
        "applovin.com", "vungle.com", "inmobi.com", "startapp.com",
        "chartboost.com", "mopub.com", "adcolony.com", "ironsrc.com",
        "smaato.com", "flurry.com", "exoclick.com", "propellerads.com",
        "popads.net", "adroll.com", "bing-shopping.microsoft.com"
    )

    private val emptyResponse: WebResourceResponse
        get() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    fun isBlockedUrl(url: String): Boolean {
        val host = try {
            Uri.parse(url).host?.lowercase()
        } catch (e: Exception) {
            null
        } ?: return false
        return BLOCKED_DOMAINS.any { host == it || host.endsWith(".$it") }
    }

    fun blockedResponse(): WebResourceResponse = emptyResponse
}
