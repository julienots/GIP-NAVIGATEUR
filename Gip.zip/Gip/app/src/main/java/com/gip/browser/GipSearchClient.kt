package com.gip.browser

import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Coeur du moteur "Gip Search".
 *
 * À propos de l'indépendance :
 * construire un vrai crawler + index du web (des milliards de pages) est hors
 * de portée d'une application mobile, et aucun moteur "indépendant" grand
 * public (Ecosia, Presearch, Startpage, l'ancien Qwant...) ne le fait
 * réellement : ils s'appuient tous sur un ou plusieurs fournisseurs d'index
 * en coulisses. Gip Search fait pareil, mais assume toute la couche produit :
 * c'est Gip qui interroge les sources, fusionne les résultats, met en avant
 * ce qui vous concerne, et affiche tout dans SA propre page - jamais un
 * pixel, une police ou un script d'un moteur tiers n'apparaît à l'écran.
 *
 * Sources utilisées en coulisses :
 *  - Réponse rapide : API publique de Wikipédia (indépendante de tout moteur
 *    de recherche, aucune clé requise).
 *  - Résultats web : index HTML public de DuckDuckGo (le seul accessible
 *    sans clé API ni compte développeur). Le HTML brut est parsé côté
 *    serveur-app puis jeté : la page DuckDuckGo elle-même n'est jamais
 *    chargée ni affichée.
 */
object GipSearchClient {

    data class WebResult(
        val title: String,
        val url: String,
        val snippet: String,
        val isFrequentlyVisited: Boolean = false
    )

    data class InstantAnswer(val title: String, val extract: String, val sourceUrl: String)

    data class SearchResponse(
        val query: String,
        val instantAnswer: InstantAnswer?,
        val results: List<WebResult>
    )

    private const val DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"

    /** Lance la recherche sur un thread séparé et renvoie le résultat sur le thread UI. */
    fun search(
        query: String,
        safeSearch: Boolean,
        knownDomains: Set<String>,
        callback: (Result<SearchResponse>) -> Unit
    ) {
        Thread {
            val outcome = try {
                Result.success(performSearch(query, safeSearch, knownDomains))
            } catch (e: Exception) {
                Result.failure<SearchResponse>(e)
            }
            Handler(Looper.getMainLooper()).post { callback(outcome) }
        }.start()
    }

    private fun performSearch(
        query: String,
        safeSearch: Boolean,
        knownDomains: Set<String>
    ): SearchResponse {
        val instantAnswer = try {
            fetchWikipediaAnswer(query)
        } catch (e: Exception) {
            null
        }
        val results = try {
            fetchWebResults(query, safeSearch, knownDomains)
        } catch (e: Exception) {
            emptyList()
        }
        if (instantAnswer == null && results.isEmpty()) {
            throw IllegalStateException("Aucune source n'a répondu")
        }
        return SearchResponse(query, instantAnswer, results)
    }

    // -----------------------------------------------------------------
    // Réponse rapide (Wikipédia — totalement indépendant de DuckDuckGo)
    // -----------------------------------------------------------------

    private fun fetchWikipediaAnswer(query: String): InstantAnswer? {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val searchJson = get(
            "https://fr.wikipedia.org/w/api.php?action=opensearch&limit=1&format=json&search=$encoded"
        )
        val titles = JSONArray(searchJson).optJSONArray(1) ?: return null
        if (titles.length() == 0) return null
        val title = titles.getString(0)

        val summaryJson = get("https://fr.wikipedia.org/api/rest_v1/page/summary/${Uri.encode(title)}")
        val obj = JSONObject(summaryJson)
        val extract = obj.optString("extract").takeIf { it.isNotBlank() } ?: return null
        val pageUrl = obj.optJSONObject("content_urls")
            ?.optJSONObject("desktop")
            ?.optString("page")
            ?.takeIf { it.isNotBlank() }
            ?: "https://fr.wikipedia.org/wiki/${Uri.encode(title)}"

        return InstantAnswer(obj.optString("title", title), extract, pageUrl)
    }

    // -----------------------------------------------------------------
    // Résultats web
    // -----------------------------------------------------------------

    private fun fetchWebResults(
        query: String,
        safeSearch: Boolean,
        knownDomains: Set<String>
    ): List<WebResult> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val safeParam = if (safeSearch) "&kp=1" else "&kp=-2"
        val html = get("https://html.duckduckgo.com/html/?q=$encoded$safeParam")
        val doc = Jsoup.parse(html)

        val results = mutableListOf<WebResult>()
        for (el in doc.select("div.result")) {
            val linkEl = el.selectFirst("a.result__a") ?: continue
            val url = resolveRedirectUrl(linkEl.attr("href"))
            val title = linkEl.text().trim()
            val snippet = el.selectFirst("a.result__snippet, div.result__snippet")
                ?.text()
                ?.trim()
                .orEmpty()
            if (title.isBlank() || url.isBlank()) continue

            val host = hostOf(url)
            // Personnalisation possible uniquement par Gip : seule l'appli connaît
            // votre historique local, un moteur classique ne le voit jamais.
            val known = host != null && knownDomains.any { host == it || host.endsWith(".$it") }
            results.add(WebResult(title, url, snippet, known))
        }
        return results
    }

    private fun resolveRedirectUrl(href: String): String {
        return try {
            val full = if (href.startsWith("//")) "https:$href" else href
            val uri = Uri.parse(full)
            uri.getQueryParameter("uddg")?.let { Uri.decode(it) } ?: full
        } catch (e: Exception) {
            href
        }
    }

    private fun hostOf(url: String): String? = try {
        Uri.parse(url).host?.removePrefix("www.")
    } catch (e: Exception) {
        null
    }

    private fun get(urlString: String): String {
        val connection = URL(urlString).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.setRequestProperty("User-Agent", DESKTOP_UA)
        connection.connectTimeout = 8000
        connection.readTimeout = 8000
        connection.instanceFollowRedirects = true
        return try {
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
}
