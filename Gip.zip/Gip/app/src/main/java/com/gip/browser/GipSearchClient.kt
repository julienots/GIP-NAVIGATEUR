package com.gip.browser

import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.CountDownLatch

/**
 * Coeur du moteur "Gip Search".
 *
 * À propos de l'indépendance :
 * construire un vrai crawler + index du web (des milliards de pages) est hors
 * de portée d'une application mobile, et aucun moteur "indépendant" grand
 * public (Ecosia, Presearch, Startpage, l'ancien Qwant...) ne le fait
 * réellement : ils s'appuient tous sur un ou plusieurs fournisseurs d'index
 * en coulisses. Gip Search fait pareil, mais assume toute la couche produit :
 * c'est Gip qui interroge les sources EN PARALLÈLE (pour aller vite), fusionne
 * les résultats, met en avant ce qui vous concerne, gère la pagination, et
 * affiche tout dans SA propre page - jamais un pixel, une police ou un script
 * d'un moteur tiers n'apparaît à l'écran.
 *
 * Sources utilisées en coulisses :
 *  - Réponse rapide + vignette : API publique de Wikipédia (indépendante de
 *    tout moteur de recherche, aucune clé requise).
 *  - Résultats web : index HTML public de DuckDuckGo, avec pagination (page
 *    suivante = décalage de résultats) pour permettre "Voir plus de résultats".
 *  - Catégorie Images : API publique Openverse (contenus sous licence libre,
 *    totalement indépendante de DuckDuckGo, aucune clé requise).
 */
object GipSearchClient {

    data class WebResult(
        val title: String,
        val url: String,
        val snippet: String,
        val isFrequentlyVisited: Boolean = false
    )

    data class InstantAnswer(
        val title: String,
        val extract: String,
        val sourceUrl: String,
        val thumbnailUrl: String? = null
    )

    data class ImageResult(
        val thumbnailUrl: String,
        val fallbackThumbnailUrl: String,
        val fullUrl: String,
        val title: String,
        val sourceUrl: String
    )

    data class SearchResponse(
        val query: String,
        val instantAnswer: InstantAnswer?,
        val computedAnswer: InstantCompute.Answer?,
        val weatherAnswer: GipInstantServices.WeatherAnswer?,
        val currencyAnswer: InstantCompute.Answer?,
        val results: List<WebResult>,
        val relatedSearches: List<String>,
        val nextOffset: Int
    )

    private const val DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"

    private const val RESULTS_PER_PAGE = 30
    // Depuis la v2.5.5 de l'API Openverse, toute requête anonyme (sans clé API)
    // demandant plus de 20 résultats par page est rejetée avec une erreur 401 —
    // c'était la cause réelle du bug "aucune image ne s'affiche jamais" dans
    // l'onglet Images : la requête entière échouait avant même d'arriver aux
    // vignettes. 20 est le maximum autorisé sans authentification.
    private const val IMAGES_PER_PAGE = 20

    // Petit cache mémoire pour rendre instantanés les retours sur une recherche
    // déjà faite dans la session (bouton retour, changement d'onglet Web/Images...).
    private val responseCache = LinkedHashMap<String, SearchResponse>()
    private val imageCache = LinkedHashMap<String, List<ImageResult>>()
    private const val CACHE_LIMIT = 20

    // -----------------------------------------------------------------
    // Recherche web (première page) : réponse rapide + résultats en parallèle
    // -----------------------------------------------------------------

    fun search(
        query: String,
        safeSearch: Boolean,
        knownDomains: Set<String>,
        callback: (Result<SearchResponse>) -> Unit
    ) {
        val cacheKey = "$query|$safeSearch"
        responseCache[cacheKey]?.let {
            callback(Result.success(it))
            return
        }
        Thread {
            val outcome = try {
                Result.success(performSearch(query, safeSearch, knownDomains, offset = 0))
            } catch (e: Exception) {
                Result.failure<SearchResponse>(e)
            }
            outcome.getOrNull()?.let { cachePut(responseCache, cacheKey, it) }
            Handler(Looper.getMainLooper()).post { callback(outcome) }
        }.start()
    }

    /** Page suivante de résultats web, pour le bouton "Voir plus de résultats". */
    fun searchMore(
        query: String,
        safeSearch: Boolean,
        knownDomains: Set<String>,
        offset: Int,
        callback: (Result<List<WebResult>>) -> Unit
    ) {
        Thread {
            val outcome = try {
                Result.success(rankAndDiversify(query, fetchWebResults(query, safeSearch, knownDomains, offset)))
            } catch (e: Exception) {
                Result.failure<List<WebResult>>(e)
            }
            Handler(Looper.getMainLooper()).post { callback(outcome) }
        }.start()
    }

    // -----------------------------------------------------------------
    // Suggestions / recherches associées (API publique DuckDuckGo, sans clé)
    // -----------------------------------------------------------------

    private val suggestCache = LinkedHashMap<String, List<String>>()

    /** Suggestions de complétion pendant la frappe, affichées sous la barre de recherche. */
    fun suggest(query: String, callback: (List<String>) -> Unit) {
        if (query.isBlank()) {
            callback(emptyList())
            return
        }
        suggestCache[query]?.let {
            callback(it)
            return
        }
        Thread {
            val list = try { fetchSuggestions(query) } catch (e: Exception) { emptyList() }
            cachePut(suggestCache, query, list)
            Handler(Looper.getMainLooper()).post { callback(list) }
        }.start()
    }

    private fun fetchSuggestions(query: String): List<String> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        // "kl=fr-fr" : région French/France, pour des suggestions pertinentes
        // pour un usage francophone plutôt que par défaut anglophone US.
        val json = get("https://duckduckgo.com/ac/?q=$encoded&type=list&kl=fr-fr")
        val arr = JSONArray(json)
        // Format DuckDuckGo : [query, [suggestion1, suggestion2, ...]]
        val suggestionsArr = arr.optJSONArray(1) ?: return emptyList()
        val out = mutableListOf<String>()
        for (i in 0 until suggestionsArr.length()) {
            suggestionsArr.optString(i)?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        }
        return out
    }

    // -----------------------------------------------------------------
    // Classement + diversité des résultats
    // -----------------------------------------------------------------

    /**
     * DuckDuckGo renvoie déjà un ordre pertinent, mais on l'affine avec des
     * critères propres à Gip : nombre de mots de la requête retrouvés dans le
     * titre/l'extrait, léger bonus aux domaines déjà connus de l'utilisateur,
     * et une limite de résultats consécutifs d'un même domaine pour éviter
     * qu'un seul site monopolise la première page.
     */
    private fun rankAndDiversify(query: String, results: List<WebResult>): List<WebResult> {
        if (results.isEmpty()) return results
        val terms = query.lowercase().split(" ").map { it.trim() }.filter { it.length >= 2 }

        fun score(r: WebResult): Int {
            val haystack = (r.title + " " + r.snippet).lowercase()
            var s = terms.count { haystack.contains(it) } * 2
            if (r.isFrequentlyVisited) s += 3
            if (terms.isNotEmpty() && r.title.lowercase().startsWith(terms.first())) s += 1
            return s
        }

        val ordered = results.withIndex()
            .sortedWith(compareByDescending<IndexedValue<WebResult>> { score(it.value) }.thenBy { it.index })
            .map { it.value }

        // Diversité : jamais plus de 2 résultats consécutifs du même domaine.
        val diversified = mutableListOf<WebResult>()
        val pending = ArrayDeque(ordered)
        val recentDomains = ArrayDeque<String>()
        while (pending.isNotEmpty()) {
            val idx = pending.indexOfFirst { candidate ->
                val host = hostOf(candidate.url) ?: ""
                recentDomains.count { it == host } < 2
            }.let { if (it == -1) 0 else it }
            val chosen = pending.removeAt(idx)
            diversified.add(chosen)
            val host = hostOf(chosen.url) ?: ""
            recentDomains.addLast(host)
            if (recentDomains.size > 2) recentDomains.removeFirst()
        }
        return diversified
    }

    private fun performSearch(
        query: String,
        safeSearch: Boolean,
        knownDomains: Set<String>,
        offset: Int
    ): SearchResponse {
        // Réponse instantanée locale (calcul / conversion) : gratuite, aucun réseau.
        val computedAnswer = InstantCompute.compute(query)

        // Services Gip Météo / Gip Devises : chaque fonction renvoie tout de
        // suite `null`, sans requête réseau, si la requête ne ressemble pas à
        // une demande de météo / de conversion de devise, donc ceci ne
        // ralentit jamais une recherche normale.
        val weatherAnswer = if (computedAnswer == null) {
            try { GipInstantServices.fetchWeather(query) } catch (e: Exception) { null }
        } else null
        val currencyAnswer = if (computedAnswer == null && weatherAnswer == null) {
            try { GipInstantServices.fetchCurrency(query) } catch (e: Exception) { null }
        } else null
        val hasDirectAnswer = computedAnswer != null || weatherAnswer != null || currencyAnswer != null

        // On lance la réponse rapide (Wikipédia), les résultats web (DuckDuckGo)
        // et les recherches associées (suggestions DuckDuckGo) EN MÊME TEMPS
        // plutôt que les uns après les autres : la recherche est nettement
        // plus rapide à l'affichage.
        var instantAnswer: InstantAnswer? = null
        var results: List<WebResult> = emptyList()
        var related: List<String> = emptyList()
        val latch = CountDownLatch(3)

        // Si on a déjà une réponse directe (calcul, météo, devise), pas besoin
        // d'interroger Wikipédia : la réponse instantanée est déjà affichée.
        if (!hasDirectAnswer) {
            Thread {
                instantAnswer = try { fetchWikipediaAnswer(query) } catch (e: Exception) { null }
                latch.countDown()
            }.start()
        } else {
            latch.countDown()
        }

        Thread {
            results = try { rankAndDiversify(query, fetchWebResults(query, safeSearch, knownDomains, offset)) } catch (e: Exception) { emptyList() }
            latch.countDown()
        }.start()

        Thread {
            related = try { fetchSuggestions(query).filter { !it.equals(query, ignoreCase = true) }.take(6) } catch (e: Exception) { emptyList() }
            latch.countDown()
        }.start()

        latch.await()

        if (!hasDirectAnswer && instantAnswer == null && results.isEmpty()) {
            throw IllegalStateException("Aucune source n'a répondu")
        }
        return SearchResponse(
            query, instantAnswer, computedAnswer, weatherAnswer, currencyAnswer, results, related,
            nextOffset = offset + RESULTS_PER_PAGE
        )
    }

    // -----------------------------------------------------------------
    // Réponse rapide (Wikipédia — totalement indépendant de DuckDuckGo)
    // -----------------------------------------------------------------

    private fun fetchWikipediaAnswer(query: String): InstantAnswer? {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val searchJson = get(
            "https://fr.wikipedia.org/w/api.php?action=opensearch&limit=1&format=json&search=$encoded"
        )
        val titles = JSONArray(searchJson).optJSONArray(1) ?: return null
        if (titles.length() == 0) return null
        val title = titles.getString(0)

        val summaryJson = get("https://fr.wikipedia.org/api/rest_v1/page/summary/${Uri.encode(title)}")
        val obj = JSONObject(summaryJson)
        val extract = obj.optString("extract").takeIf { it.isNotBlank() } ?: return null
        val pageUrl = obj.optJSONObject("content_urls")
            ?.optJSONObject("desktop")
            ?.optString("page")
            ?.takeIf { it.isNotBlank() }
            ?: "https://fr.wikipedia.org/wiki/${Uri.encode(title)}"
        val thumbnail = obj.optJSONObject("thumbnail")?.optString("source")?.takeIf { it.isNotBlank() }

        return InstantAnswer(obj.optString("title", title), extract, pageUrl, thumbnail)
    }

    // -----------------------------------------------------------------
    // Résultats web (avec pagination)
    // -----------------------------------------------------------------

    private fun fetchWebResults(
        query: String,
        safeSearch: Boolean,
        knownDomains: Set<String>,
        offset: Int
    ): List<WebResult> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val safeParam = if (safeSearch) "&kp=1" else "&kp=-2"
        val offsetParam = if (offset > 0) "&s=$offset" else ""
        // "kl=fr-fr" : région French/France, pour des résultats pertinents pour
        // un usage francophone plutôt que par défaut anglophone US.
        val html = get("https://html.duckduckgo.com/html/?q=$encoded$safeParam$offsetParam&kl=fr-fr")
        val doc = Jsoup.parse(html)

        // Il arrive que la source réponde par une page d'avertissement / de
        // vérification plutôt que par des résultats (trafic jugé suspect,
        // limite de débit...). Sans cette détection, Gip afficherait
        // silencieusement "aucun résultat" sans que l'utilisateur comprenne
        // pourquoi une recherche pourtant valide ne renvoie rien : mieux vaut
        // le signaler clairement pour distinguer ce cas d'une vraie absence
        // de résultats.
        if (doc.select("div.result, div.web-result, div.results_links, div.results_links_deep").isEmpty() &&
            (html.contains("anomaly-modal", ignoreCase = true) ||
                html.contains("unusual traffic", ignoreCase = true) ||
                html.contains("trafic inhabituel", ignoreCase = true))
        ) {
            throw IllegalStateException("Source de résultats web temporairement indisponible (trafic limité).")
        }

        // Plusieurs variantes de sélecteurs selon la mise en page renvoyée,
        // pour ne pas passer à côté de résultats et en afficher davantage.
        val nodes = doc.select("div.result, div.web-result, div.results_links, div.results_links_deep")

        val results = mutableListOf<WebResult>()
        val seenUrls = mutableSetOf<String>()
        for (el in nodes) {
            val linkEl = el.selectFirst(
                "a.result__a, a.result__url, a[data-testid=result-title-a], h2 a, h2.result__title a"
            ) ?: continue
            val url = resolveRedirectUrl(linkEl.attr("href"))
            val title = linkEl.text().trim()
            val snippet = el.selectFirst(
                "a.result__snippet, div.result__snippet, span[data-testid=result-snippet], .snippet"
            )
                ?.text()
                ?.trim()
                .orEmpty()
            if (title.isBlank() || url.isBlank() || !seenUrls.add(url)) continue

            val host = hostOf(url)
            // Personnalisation possible uniquement par Gip : seule l'appli connaît
            // votre historique local, un moteur classique ne le voit jamais.
            val known = host != null && knownDomains.any { host == it || host.endsWith(".$it") }
            results.add(WebResult(title, url, snippet, known))
        }
        return results
    }

    // -----------------------------------------------------------------
    // Catégorie Images (Openverse — indépendant, contenus sous licence libre)
    // -----------------------------------------------------------------

    fun searchImages(query: String, callback: (Result<List<ImageResult>>) -> Unit) {
        val cacheKey = "$query|1"
        imageCache[cacheKey]?.let {
            callback(Result.success(it))
            return
        }
        Thread {
            val outcome = try {
                Result.success(fetchImageResults(query, page = 1))
            } catch (e: Exception) {
                Result.failure<List<ImageResult>>(e)
            }
            outcome.getOrNull()?.let { cachePut(imageCache, cacheKey, it) }
            Handler(Looper.getMainLooper()).post { callback(outcome) }
        }.start()
    }

    /** Page suivante d'images, pour le bouton "Voir plus d'images". */
    fun searchMoreImages(query: String, page: Int, callback: (Result<List<ImageResult>>) -> Unit) {
        val cacheKey = "$query|$page"
        imageCache[cacheKey]?.let {
            callback(Result.success(it))
            return
        }
        Thread {
            val outcome = try {
                Result.success(fetchImageResults(query, page))
            } catch (e: Exception) {
                Result.failure<List<ImageResult>>(e)
            }
            outcome.getOrNull()?.let { cachePut(imageCache, cacheKey, it) }
            Handler(Looper.getMainLooper()).post { callback(outcome) }
        }.start()
    }

    /**
     * Récupère une page d'images depuis Openverse.
     *
     * Important : on ne charge JAMAIS la miniature via le champ brut
     * "thumbnail"/"url" renvoyé par certains fournisseurs (Flickr, musées,
     * Wikimedia...) car beaucoup bloquent le "hotlinking" (chargement direct
     * hors navigateur, sans le bon Referer/User-Agent) et renvoient une
     * erreur 403 — c'est la cause la plus fréquente d'images qui ne
     * s'affichent jamais. On utilise donc en priorité le proxy de vignette
     * officiel d'Openverse ("/thumb/"), qui va chercher l'image côté serveur
     * et la sert de façon fiable ; le champ brut ne sert plus que de repli.
     */
    private fun fetchImageResults(query: String, page: Int): List<ImageResult> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val json = get("https://api.openverse.org/v1/images/?q=$encoded&page_size=$IMAGES_PER_PAGE&page=$page")
        val arr = JSONObject(json).optJSONArray("results") ?: return emptyList()
        val out = mutableListOf<ImageResult>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val id = obj.optString("id").takeIf { it.isNotBlank() }
            val rawThumb = obj.optString("thumbnail").takeIf { it.isNotBlank() }
            val full = obj.optString("url").takeIf { it.isNotBlank() } ?: rawThumb ?: continue
            val proxiedThumb = id?.let { "https://api.openverse.org/v1/images/$it/thumb/" }
            val thumb = proxiedThumb ?: rawThumb ?: full
            val fallbackThumb = rawThumb ?: full
            val title = obj.optString("title").takeIf { it.isNotBlank() } ?: query
            val source = obj.optString("foreign_landing_url").takeIf { it.isNotBlank() } ?: full
            out.add(ImageResult(thumb, fallbackThumb, full, title, source))
        }
        return out
    }

    // -----------------------------------------------------------------
    // Utilitaires
    // -----------------------------------------------------------------

    private fun <K, V> cachePut(cache: LinkedHashMap<K, V>, key: K, value: V) {
        cache[key] = value
        if (cache.size > CACHE_LIMIT) {
            val oldest = cache.keys.firstOrNull()
            if (oldest != null) cache.remove(oldest)
        }
    }

    private fun resolveRedirectUrl(href: String): String {
        return try {
            val full = if (href.startsWith("//")) "https:$href" else href
            val uri = Uri.parse(full)
            uri.getQueryParameter("uddg")?.let { Uri.decode(it) } ?: full
        } catch (e: Exception) {
            href
        }
    }

    private fun hostOf(url: String): String? = try {
        Uri.parse(url).host?.removePrefix("www.")
    } catch (e: Exception) {
        null
    }

    private fun get(urlString: String): String {
        val connection = URL(urlString).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.setRequestProperty("User-Agent", DESKTOP_UA)
        // 8 s pouvait couper une requête légitime mais lente (réseau mobile
        // faible, source momentanément chargée) ; 12 s laisse une vraie marge
        // sans pour autant bloquer l'interface longtemps en cas de panne réelle.
        connection.connectTimeout = 12000
        connection.readTimeout = 12000
        connection.instanceFollowRedirects = true
        return try {
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
}
