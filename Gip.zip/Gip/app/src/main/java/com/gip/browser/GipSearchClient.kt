package com.gip.browser

import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.CountDownLatch

/**
 * Coeur du moteur "Gip Search".
 *
 * À propos de l'indépendance :
 * construire un vrai crawler + index du web (des milliards de pages) est hors
 * de portée d'une application mobile, et aucun moteur "indépendant" grand
 * public (Ecosia, Presearch, Startpage, l'ancien Qwant...) ne le fait
 * réellement : ils s'appuient tous sur un ou plusieurs fournisseurs d'index
 * en coulisses. Gip Search fait pareil, mais assume toute la couche produit :
 * c'est Gip qui interroge les sources EN PARALLÈLE (pour aller vite), fusionne
 * les résultats, met en avant ce qui vous concerne, gère la pagination, et
 * affiche tout dans SA propre page - jamais un pixel, une police ou un script
 * d'un moteur tiers n'apparaît à l'écran.
 *
 * Sources utilisées en coulisses :
 *  - Réponse rapide + vignette : API publique de Wikipédia (indépendante de
 *    tout moteur de recherche, aucune clé requise).
 *  - Résultats web : index HTML public de DuckDuckGo, avec pagination (page
 *    suivante = décalage de résultats) pour permettre "Voir plus de résultats".
 *  - Catégorie Images : API publique Openverse (contenus sous licence libre,
 *    totalement indépendante de DuckDuckGo, aucune clé requise).
 */
object GipSearchClient {

    data class WebResult(
        val title: String,
        val url: String,
        val snippet: String,
        val isFrequentlyVisited: Boolean = false
    )

    data class InstantAnswer(
        val title: String,
        val extract: String,
        val sourceUrl: String,
        val thumbnailUrl: String? = null
    )

    data class ImageResult(
        val thumbnailUrl: String,
        val fullUrl: String,
        val title: String,
        val sourceUrl: String
    )

    data class SearchResponse(
        val query: String,
        val instantAnswer: InstantAnswer?,
        val results: List<WebResult>,
        val nextOffset: Int
    )

    private const val DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"

    private const val RESULTS_PER_PAGE = 30

    // Petit cache mémoire pour rendre instantanés les retours sur une recherche
    // déjà faite dans la session (bouton retour, changement d'onglet Web/Images...).
    private val responseCache = java.util.Collections.synchronizedMap(LinkedHashMap<String, SearchResponse>())
    private val imageCache = java.util.Collections.synchronizedMap(LinkedHashMap<String, List<ImageResult>>())
    private const val CACHE_LIMIT = 20

    // -----------------------------------------------------------------
    // Recherche web (première page) : réponse rapide + résultats en parallèle
    // -----------------------------------------------------------------

    fun search(
        query: String,
        safeSearch: Boolean,
        knownDomains: Set<String>,
        callback: (Result<SearchResponse>) -> Unit
    ) {
        val cacheKey = "$query|$safeSearch"
        responseCache[cacheKey]?.let {
            callback(Result.success(it))
            return
        }
        Thread {
            val outcome = try {
                Result.success(performSearch(query, safeSearch, knownDomains, offset = 0))
            } catch (e: Exception) {
                Result.failure<SearchResponse>(e)
            }
            outcome.getOrNull()?.let { cachePut(responseCache, cacheKey, it) }
            Handler(Looper.getMainLooper()).post { callback(outcome) }
        }.start()
    }

    /** Page suivante de résultats web, pour le bouton "Voir plus de résultats". */
    fun searchMore(
        query: String,
        safeSearch: Boolean,
        knownDomains: Set<String>,
        offset: Int,
        callback: (Result<List<WebResult>>) -> Unit
    ) {
        Thread {
            val outcome = try {
                Result.success(fetchWebResults(query, safeSearch, knownDomains, offset))
            } catch (e: Exception) {
                Result.failure<List<WebResult>>(e)
            }
            Handler(Looper.getMainLooper()).post { callback(outcome) }
        }.start()
    }

    private fun performSearch(
        query: String,
        safeSearch: Boolean,
        knownDomains: Set<String>,
        offset: Int
    ): SearchResponse {
        // On lance la réponse rapide (Wikipédia) et les résultats web (DuckDuckGo)
        // EN MÊME TEMPS plutôt que l'un après l'autre : la recherche est ~2x
        // plus rapide à l'affichage.
        var instantAnswer: InstantAnswer? = null
        var results: List<WebResult> = emptyList()
        val latch = CountDownLatch(2)

        Thread {
            instantAnswer = try { fetchWikipediaAnswer(query) } catch (e: Exception) { null }
            latch.countDown()
        }.start()

        Thread {
            results = try { fetchWebResults(query, safeSearch, knownDomains, offset) } catch (e: Exception) { emptyList() }
            latch.countDown()
        }.start()

        latch.await()

        if (instantAnswer == null && results.isEmpty()) {
            throw IllegalStateException("Aucune source n'a répondu")
        }
        return SearchResponse(query, instantAnswer, results, nextOffset = offset + RESULTS_PER_PAGE)
    }

    // -----------------------------------------------------------------
    // Réponse rapide (Wikipédia — totalement indépendant de DuckDuckGo)
    // -----------------------------------------------------------------

    private fun fetchWikipediaAnswer(query: String): InstantAnswer? {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val searchJson = get(
            "https://fr.wikipedia.org/w/api.php?action=opensearch&limit=1&format=json&search=$encoded"
        )
        val titles = JSONArray(searchJson).optJSONArray(1) ?: return null
        if (titles.length() == 0) return null
        val title = titles.getString(0)

        val summaryJson = get("https://fr.wikipedia.org/api/rest_v1/page/summary/${Uri.encode(title)}")
        val obj = JSONObject(summaryJson)
        val extract = obj.optString("extract").takeIf { it.isNotBlank() } ?: return null
        val pageUrl = obj.optJSONObject("content_urls")
            ?.optJSONObject("desktop")
            ?.optString("page")
            ?.takeIf { it.isNotBlank() }
            ?: "https://fr.wikipedia.org/wiki/${Uri.encode(title)}"
        val thumbnail = obj.optJSONObject("thumbnail")?.optString("source")?.takeIf { it.isNotBlank() }

        return InstantAnswer(obj.optString("title", title), extract, pageUrl, thumbnail)
    }

    // -----------------------------------------------------------------
    // Résultats web (avec pagination)
    // -----------------------------------------------------------------

    private fun fetchWebResults(
        query: String,
        safeSearch: Boolean,
        knownDomains: Set<String>,
        offset: Int
    ): List<WebResult> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val safeParam = if (safeSearch) "&kp=1" else "&kp=-2"
        val offsetParam = if (offset > 0) "&s=$offset" else ""
        val html = get("https://html.duckduckgo.com/html/?q=$encoded$safeParam$offsetParam")
        val doc = Jsoup.parse(html)

        // Plusieurs variantes de sélecteurs selon la mise en page renvoyée,
        // pour ne pas passer à côté de résultats et en afficher davantage.
        val nodes = doc.select(
            "div.result, div.web-result, div.results_links, div.results_links_deep, " +
                "article[data-testid=result], article.result, .result.results_links"
        )

        val results = mutableListOf<WebResult>()
        val seenUrls = mutableSetOf<String>()
        for (el in nodes) {
            val linkEl = el.selectFirst("a.result__a, a.result__url, h2 a") ?: continue
            val url = normalizeResultUrl(resolveRedirectUrl(linkEl.attr("href")))
            val title = linkEl.text().trim()
            val snippet = el.selectFirst("a.result__snippet, div.result__snippet, .snippet")
                ?.text()
                ?.trim()
                .orEmpty()
            if (title.isBlank() || url.isBlank() || !seenUrls.add(url)) continue

            val host = hostOf(url)
            // Personnalisation possible uniquement par Gip : seule l'appli connaît
            // votre historique local, un moteur classique ne le voit jamais.
            val known = host != null && knownDomains.any { host == it || host.endsWith(".$it") }
            results.add(WebResult(title, url, snippet, known))
        }
        // Classement Gip : pertinence textuelle + correspondance du domaine +
        // légère diversité des domaines. Cela évite de simplement afficher
        // l'ordre brut du fournisseur et rend le moteur nettement plus utile.
        val terms = query.lowercase()
            .split(Regex("\\s+"))
            .map { it.trim(' ', ',', '.', ';', ':', '!', '?', '(', ')', '[', ']', '{', '}') }
            .filter { it.length >= 2 }
            .distinct()

        val scored = results.mapIndexed { index, item ->
            val title = item.title.lowercase()
            val snippet = item.snippet.lowercase()
            val host = hostOf(item.url).orEmpty().lowercase()
            var score = 0.0
            for (term in terms) {
                if (title.contains(term)) score += 8.0
                if (snippet.contains(term)) score += 2.5
                if (host.contains(term)) score += 3.0
            }
            if (item.isFrequentlyVisited) score += 2.0
            // Les premiers résultats restent légèrement favorisés pour éviter
            // qu'un simple mot générique ne bouleverse complètement le classement.
            score += (results.size - index) * 0.02
            item to score
        }

        val diversified = mutableListOf<WebResult>()
        val domainCount = mutableMapOf<String, Int>()
        for ((item, _) in scored.sortedByDescending { it.second }) {
            val domain = hostOf(item.url).orEmpty()
            val count = domainCount[domain] ?: 0
            if (count >= 4) continue
            domainCount[domain] = count + 1
            diversified += item
        }
        return diversified
    }

    // -----------------------------------------------------------------
    // Catégorie Images (Openverse — indépendant, contenus sous licence libre)
    // -----------------------------------------------------------------

    fun searchImages(query: String, callback: (Result<List<ImageResult>>) -> Unit) {
        imageCache[query]?.let {
            callback(Result.success(it))
            return
        }
        Thread {
            val outcome = try {
                Result.success(fetchImageResults(query))
            } catch (e: Exception) {
                Result.failure<List<ImageResult>>(e)
            }
            outcome.getOrNull()?.let { cachePut(imageCache, query, it) }
            Handler(Looper.getMainLooper()).post { callback(outcome) }
        }.start()
    }

    private fun fetchImageResults(query: String): List<ImageResult> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val json = get("https://api.openverse.org/v1/images/?q=$encoded&page_size=24")
        val arr = JSONObject(json).optJSONArray("results") ?: return emptyList()
        val out = mutableListOf<ImageResult>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val thumb = obj.optString("thumbnail").takeIf { it.isNotBlank() }
                ?: obj.optString("url").takeIf { it.isNotBlank() }
                ?: continue
            val full = obj.optString("url").takeIf { it.isNotBlank() } ?: thumb
            val title = obj.optString("title", query)
            val source = obj.optString("foreign_landing_url", full)
            out.add(ImageResult(thumb, full, title, source))
        }
        return out
    }

    // -----------------------------------------------------------------
    // Utilitaires
    // -----------------------------------------------------------------

    private fun <K, V> cachePut(cache: MutableMap<K, V>, key: K, value: V) {
        cache[key] = value
        if (cache.size > CACHE_LIMIT) {
            val oldest = cache.keys.firstOrNull()
            if (oldest != null) cache.remove(oldest)
        }
    }

    private fun normalizeResultUrl(url: String): String {
        return try {
            val uri = Uri.parse(url)
            val scheme = uri.scheme?.lowercase() ?: return url
            if (scheme != "http" && scheme != "https") return ""
            val builder = uri.buildUpon().clearQuery()
            val query = uri.queryParameterNames
                .filterNot { it.equals("utm_source", true) || it.startsWith("utm_", true) ||
                    it.equals("fbclid", true) || it.equals("gclid", true) }
                .joinToString("&") { key ->
                    Uri.encode(key) + "=" + Uri.encode(uri.getQueryParameter(key).orEmpty())
                }
            if (query.isNotBlank()) builder.encodedQuery(query)
            builder.build().toString().removeSuffix("/")
        } catch (_: Exception) {
            url
        }
    }

    private fun resolveRedirectUrl(href: String): String {
        return try {
            val full = if (href.startsWith("//")) "https:$href" else href
            val uri = Uri.parse(full)
            uri.getQueryParameter("uddg")?.let { Uri.decode(it) } ?: full
        } catch (e: Exception) {
            href
        }
    }

    private fun hostOf(url: String): String? = try {
        Uri.parse(url).host?.removePrefix("www.")
    } catch (e: Exception) {
        null
    }

    private fun get(urlString: String): String {
        val connection = URL(urlString).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.setRequestProperty("User-Agent", DESKTOP_UA)
        connection.connectTimeout = 8000
        connection.readTimeout = 8000
        connection.instanceFollowRedirects = true
        return try {
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
}
